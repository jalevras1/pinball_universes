import 'package:flutter_test/flutter_test.dart';
import 'package:premium_pinball/game/machine_rules.dart';
import 'package:premium_pinball/game/physics_contact.dart';
import 'package:premium_pinball/game/shooter_guide.dart';

void main() {
  test('all charged plunges feed the ball onto the table', () {
    for (final charge in [0.0, 0.20, 0.52, 0.65, 0.77, 1.0]) {
      var ball = ShooterGuideState(
        x: ShooterGuide.laneX,
        y: 665,
        vx: 0,
        vy: ShooterGuide.velocityForPull(charge),
        arcTime: -1,
      );
      for (var frame = 0; frame < 700 && !ball.enteredPlayfield; frame++) {
        ball = ShooterGuide.advance(ball, 1 / 240, power: charge);
      }
      expect(ball.enteredPlayfield, isTrue, reason: '$charge plunger charge');
      expect(ball.x, lessThan(ShooterGuide.dividerX));
      expect(ball.vx, lessThan(0));
    }
  });

  test('motorized flipper delivers a controlled positive impulse', () {
    ContactResult flipper(double speed) => ContactPhysics.capsule(
      ball: const ContactBall(x: 162, y: 477, vx: 0, vy: 280),
      ax: 120,
      ay: 500,
      bx: 195,
      by: 480,
      radius: 18,
      restitution: 0.7,
      friction: 0.32,
      angularSpeed: speed,
      pivotX: 120,
      pivotY: 500,
    );
    final stationary = flipper(0);
    final powered = flipper(-10);
    expect(powered.collided, isTrue);
    expect(powered.normalImpulse, greaterThan(stationary.normalImpulse));
    expect(powered.ball.vy, lessThan(stationary.ball.vy - 250));
  });

  test('separating contact does not inject ghost energy', () {
    final result = ContactPhysics.capsule(
      ball: const ContactBall(x: 162, y: 477, vx: 0, vy: -420),
      ax: 120,
      ay: 500,
      bx: 195,
      by: 480,
      radius: 18,
      restitution: 0.6,
    );
    expect(result.normalImpulse, 0);
    expect(result.ball.vy, -420);
  });

  test('all nine machines have objective-driven rules', () {
    expect(machineProfiles, hasLength(9));
    for (final key in machineProfiles.keys) {
      final rules = MachineRules(key);
      rules.record(MachineEvent.orbit, 0);
      rules.record(MachineEvent.ramp, 1);
      expect(rules.modeIndex, 1, reason: key);
      rules.record(MachineEvent.targetBank, 2);
      rules.record(MachineEvent.rolloverBank, 3);
      expect(rules.modeIndex, 2, reason: key);
    }
  });
}
