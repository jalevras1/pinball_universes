import 'package:flutter_test/flutter_test.dart';
import 'package:premium_pinball/game/playfield_plan.dart';
import 'package:premium_pinball/game/table_data.dart';

void main() {
  test('nine machines define unique usable orbit and ramp geometry', () {
    final signatures = <String>{};
    for (final table in pinballTables) {
      final plan = playfieldFor(table);
      expect(plan.shots, hasLength(2), reason: table.title);
      expect(plan.targets.length, greaterThanOrEqualTo(3));
      expect(plan.rollovers, hasLength(3));
      for (final shot in plan.shots) {
        expect(shot.points.length, greaterThanOrEqualTo(4));
        expect(shot.score, greaterThan(0));
        for (final point in shot.points) {
          expect(point.dx, inInclusiveRange(30, 335));
          expect(point.dy, inInclusiveRange(75, 545));
        }
      }
      for (final target in plan.targets) {
        expect(target.center.dx, inInclusiveRange(35, 335));
        expect(target.center.dy, inInclusiveRange(150, 535));
      }
      final signature = plan.shots
          .map(
            (shot) => '${shot.name}:${shot.entrance.dx}:${shot.returnLane.dx}',
          )
          .join('|');
      expect(
        signatures.add(signature),
        isTrue,
        reason: 'Each table must have its own shot map: ${table.title}',
      );
    }
    expect(signatures, hasLength(9));
  });
}
