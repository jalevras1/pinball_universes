import 'dart:math' as math;

/// Mass-normalized ball-vs-capsule contact. Distances are playfield pixels,
/// velocities pixels/second, and spin radians/second. The segment can move,
/// e.g. a motorized pinball flipper. This is independent of Flutter/Flame.
class ContactBall {
  const ContactBall({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    this.spin = 0,
  });

  final double x;
  final double y;
  final double vx;
  final double vy;
  final double spin;
}

class ContactResult {
  const ContactResult({
    required this.ball,
    required this.collided,
    required this.normalImpulse,
    required this.contactFraction,
    required this.surfaceSpeed,
  });

  final ContactBall ball;
  final bool collided;
  final double normalImpulse;
  final double contactFraction;
  final double surfaceSpeed;
}

abstract final class ContactPhysics {
  /// Moving walls transfer angular momentum through tangential friction.
  /// The ball is approximated as a uniform 2D disk, I = 1/2 m r².
  static ContactResult capsule({
    required ContactBall ball,
    required double ax,
    required double ay,
    required double bx,
    required double by,
    required double radius,
    required double restitution,
    double friction = 0.18,
    double angularSpeed = 0,
    double pivotX = 0,
    double pivotY = 0,
    double surfaceVX = 0,
    double surfaceVY = 0,
  }) {
    final sx = bx - ax;
    final sy = by - ay;
    final squared = sx * sx + sy * sy;
    final projection =
        squared < 1e-8
            ? 0.0
            : ((ball.x - ax) * sx + (ball.y - ay) * sy) / squared;
    final fraction = projection.clamp(0.0, 1.0).toDouble();
    final cx = ax + fraction * sx;
    final cy = ay + fraction * sy;
    final dx = ball.x - cx;
    final dy = ball.y - cy;
    final d2 = dx * dx + dy * dy;
    if (d2 >= radius * radius) {
      return ContactResult(
        ball: ball,
        collided: false,
        normalImpulse: 0,
        contactFraction: fraction,
        surfaceSpeed: 0,
      );
    }

    final d = math.sqrt(d2);
    // For zero distance choose the normal opposite incoming relative motion.
    var nx = d > 1e-6 ? dx / d : 0.0;
    var ny = d > 1e-6 ? dy / d : -1.0;
    if (d <= 1e-6 && squared > 1e-6) {
      final length = math.sqrt(squared);
      nx = -sy / length;
      ny = sx / length;
      if (ball.vx * nx + ball.vy * ny > 0) {
        nx = -nx;
        ny = -ny;
      }
    }

    final rx = cx - pivotX;
    final ry = cy - pivotY;
    final wallVX = surfaceVX - angularSpeed * ry;
    final wallVY = surfaceVY + angularSpeed * rx;
    final relativeX = ball.vx - wallVX;
    final relativeY = ball.vy - wallVY;
    final normalSpeed = relativeX * nx + relativeY * ny;

    // Correct penetration, but never impart impact energy on separation.
    final correctedX = cx + nx * (radius + 0.01);
    final correctedY = cy + ny * (radius + 0.01);
    if (normalSpeed >= 0) {
      return ContactResult(
        ball: ContactBall(
          x: correctedX,
          y: correctedY,
          vx: ball.vx,
          vy: ball.vy,
          spin: ball.spin,
        ),
        collided: true,
        normalImpulse: 0,
        contactFraction: fraction,
        surfaceSpeed: math.sqrt(wallVX * wallVX + wallVY * wallVY),
      );
    }

    final impulse = -(1 + restitution.clamp(0.0, 1.0)) * normalSpeed;
    final tx = -ny;
    final ty = nx;
    // Contact point tangential velocity accounts for the ball's own spin.
    final vt = relativeX * tx + relativeY * ty - ball.spin * radius;
    final requestedFrictionImpulse = -vt / 3.0;
    final maxFrictionImpulse = friction.clamp(0.0, 1.0) * impulse;
    final jt =
        requestedFrictionImpulse
            .clamp(-maxFrictionImpulse, maxFrictionImpulse)
            .toDouble();
    return ContactResult(
      ball: ContactBall(
        x: correctedX,
        y: correctedY,
        vx: ball.vx + impulse * nx + jt * tx,
        vy: ball.vy + impulse * ny + jt * ty,
        spin: ball.spin - 2 * jt / radius,
      ),
      collided: true,
      normalImpulse: impulse,
      contactFraction: fraction,
      surfaceSpeed: math.sqrt(wallVX * wallVX + wallVY * wallVY),
    );
  }
}
