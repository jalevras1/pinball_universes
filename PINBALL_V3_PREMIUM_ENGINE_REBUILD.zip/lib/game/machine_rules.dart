/// Original per-machine rule logic. No asset or physics dependency, so all
/// scoring, mode advancement and multiball qualification can be replay-tested.
enum MachineEvent { orbit, ramp, targetBank, rolloverBank }

class MachineProfile {
  const MachineProfile({
    required this.orbitGoal,
    required this.rampGoal,
    required this.comboWindow,
    required this.jackpot,
    required this.multiballRamps,
    required this.featureName,
  });

  final int orbitGoal;
  final int rampGoal;
  final double comboWindow;
  final int jackpot;
  final int multiballRamps;
  final String featureName;
}

const machineProfiles = <String, MachineProfile>{
  'astralOrrery': MachineProfile(
    orbitGoal: 3,
    rampGoal: 2,
    comboWindow: 5,
    jackpot: 14000,
    multiballRamps: 3,
    featureName: 'SOLAR ALIGNMENT',
  ),
  'moonfallSanctuary': MachineProfile(
    orbitGoal: 2,
    rampGoal: 3,
    comboWindow: 6,
    jackpot: 15000,
    multiballRamps: 4,
    featureName: 'ECLIPSE LOCK',
  ),
  'nebulaTempest': MachineProfile(
    orbitGoal: 4,
    rampGoal: 2,
    comboWindow: 4,
    jackpot: 16000,
    multiballRamps: 3,
    featureName: 'STORM CELL',
  ),
  'circuitVelocity': MachineProfile(
    orbitGoal: 3,
    rampGoal: 3,
    comboWindow: 3,
    jackpot: 17500,
    multiballRamps: 3,
    featureName: 'OVERDRIVE',
  ),
  'quantumGrid': MachineProfile(
    orbitGoal: 2,
    rampGoal: 4,
    comboWindow: 4.5,
    jackpot: 18000,
    multiballRamps: 4,
    featureName: 'PHASE CASCADE',
  ),
  'reactorRush': MachineProfile(
    orbitGoal: 4,
    rampGoal: 3,
    comboWindow: 4,
    jackpot: 20000,
    multiballRamps: 4,
    featureName: 'CRITICAL MASS',
  ),
  'grandMechanism': MachineProfile(
    orbitGoal: 2,
    rampGoal: 3,
    comboWindow: 6,
    jackpot: 15500,
    multiballRamps: 3,
    featureName: 'MAIN SPRING',
  ),
  'chronoCitadel': MachineProfile(
    orbitGoal: 3,
    rampGoal: 4,
    comboWindow: 5,
    jackpot: 17000,
    multiballRamps: 4,
    featureName: 'TIME FRACTURE',
  ),
  'brassLabyrinth': MachineProfile(
    orbitGoal: 4,
    rampGoal: 4,
    comboWindow: 5.5,
    jackpot: 19000,
    multiballRamps: 5,
    featureName: 'LABYRINTH CORE',
  ),
};

class MachineAward {
  const MachineAward({
    this.bonus = 0,
    this.message = '',
    this.startMultiball = false,
    this.ballSaveSeconds = 0,
  });

  final int bonus;
  final String message;
  final bool startMultiball;
  final double ballSaveSeconds;
}

class MachineRules {
  MachineRules(String machineId)
    : profile =
          machineProfiles[machineId] ??
          (throw ArgumentError.value(
            machineId,
            'machineId',
            'Unknown machine',
          ));

  final MachineProfile profile;
  int orbits = 0;
  int ramps = 0;
  int targetBanks = 0;
  int rolloverBanks = 0;
  int modeIndex = 0;
  int combo = 0;
  int jackpots = 0;
  bool multiballTriggered = false;
  MachineEvent? _lastShot;
  double _lastShotAt = -100;
  int _nextJackpotShot = 0;

  void reset() {
    orbits = 0;
    ramps = 0;
    targetBanks = 0;
    rolloverBanks = 0;
    modeIndex = 0;
    combo = 0;
    jackpots = 0;
    multiballTriggered = false;
    _lastShot = null;
    _lastShotAt = -100;
    _nextJackpotShot = 0;
  }

  /// Keep mode progress over a drained ball, but not a timing combo chain.
  void beginBall() {
    combo = 0;
    _lastShot = null;
    _lastShotAt = -100;
  }

  String get objective => switch (modeIndex) {
    0 => 'COMPLETE TWO SHOTS',
    1 => 'CLEAR TARGETS + LANES',
    2 => 'ORBIT $orbits/${profile.orbitGoal}  RAMP $ramps/${profile.rampGoal}',
    _ => 'LIT ${profile.featureName}: SHOOT RAMP',
  };

  MachineAward record(MachineEvent event, double seconds) {
    var bonus = 0;
    var message = '';
    var ballSaveSeconds = 0.0;
    var startMultiball = false;

    switch (event) {
      case MachineEvent.orbit:
        orbits++;
      case MachineEvent.ramp:
        ramps++;
      case MachineEvent.targetBank:
        targetBanks++;
        bonus += 1500 * targetBanks.clamp(1, 4);
        message = 'TARGET BANK CLEAR';
      case MachineEvent.rolloverBank:
        rolloverBanks++;
        ballSaveSeconds = 5;
        message = 'LANES LIT • BALL SAVE';
    }

    if (event == MachineEvent.orbit || event == MachineEvent.ramp) {
      if (_lastShot != null &&
          _lastShot != event &&
          seconds - _lastShotAt <= profile.comboWindow) {
        combo = (combo + 1).clamp(1, 5);
        bonus += 1000 * combo;
        message = 'COMBO ${combo}X +${1000 * combo}';
      } else {
        combo = 0;
      }
      _lastShot = event;
      _lastShotAt = seconds;
    }

    if (modeIndex == 0 && orbits + ramps >= 2) {
      modeIndex = 1;
      bonus += 1000;
      message = 'MODE ADVANCE • +1000';
    }
    if (modeIndex == 1 && targetBanks >= 1 && rolloverBanks >= 1) {
      modeIndex = 2;
      bonus += 3000;
      message = 'MACHINE FEATURE UNLOCKED';
    }
    if (modeIndex == 2 &&
        orbits >= profile.orbitGoal &&
        ramps >= profile.rampGoal) {
      modeIndex = 3;
      bonus += 5000;
      message = '${profile.featureName} LIT';
      _nextJackpotShot = ramps + 1;
    }

    if (modeIndex == 3 &&
        event == MachineEvent.ramp &&
        ramps >= _nextJackpotShot) {
      jackpots++;
      bonus += profile.jackpot * jackpots.clamp(1, 5);
      message = '${profile.featureName} JACKPOT!';
      _nextJackpotShot = ramps + 2;
    }

    // Gameplay-dependent multiball qualification (not an arbitrary hit tally).
    if (!multiballTriggered &&
        targetBanks >= 1 &&
        ramps >= profile.multiballRamps) {
      multiballTriggered = true;
      startMultiball = true;
      ballSaveSeconds = 12;
      message = 'MULTIBALL QUALIFIED!';
    }
    return MachineAward(
      bonus: bonus,
      message: message,
      startMultiball: startMultiball,
      ballSaveSeconds: ballSaveSeconds,
    );
  }
}
