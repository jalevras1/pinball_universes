import 'dart:ui';

import 'table_data.dart';

/// Coordinates share the game's 400 x 760 machine-space.  The shot plan is the
/// single source of truth for visual geometry, hit sensors, and table rules.
/// No mechanism is baked into the printed art.
enum ShotType { orbit, raisedRamp }

class PinballShot {
  const PinballShot({
    required this.name,
    required this.type,
    required this.points,
    required this.score,
  });

  final String name;
  final ShotType type;
  final List<Offset> points;
  final int score;

  Offset get entrance => points.first;
  Offset get returnLane => points.last;
}

class PinballTarget {
  const PinballTarget(this.center, this.angle, this.score);

  final Offset center;
  final double angle;
  final int score;
}

class PlayfieldPlan {
  const PlayfieldPlan({
    required this.shots,
    required this.targets,
    required this.rollovers,
  });

  final List<PinballShot> shots;
  final List<PinballTarget> targets;
  final List<Offset> rollovers;
}

/// All nine machines have a deliberately different combination of shot routes
/// and targets, while each universe shares a coherent materials palette.
PlayfieldPlan playfieldFor(PinballTableInfo table) => switch (table.id) {
  PinballTableId.astralOrrery => const PlayfieldPlan(
    shots: [
      PinballShot(
        name: 'STAR ORBIT',
        type: ShotType.orbit,
        score: 2500,
        points: [
          Offset(88, 435),
          Offset(65, 250),
          Offset(102, 125),
          Offset(235, 93),
          Offset(311, 184),
          Offset(289, 400),
        ],
      ),
      PinballShot(
        name: 'SOLAR RAMP',
        type: ShotType.raisedRamp,
        score: 4000,
        points: [
          Offset(298, 467),
          Offset(287, 294),
          Offset(228, 199),
          Offset(160, 258),
          Offset(129, 470),
        ],
      ),
    ],
    targets: [
      PinballTarget(Offset(144, 342), -0.33, 750),
      PinballTarget(Offset(170, 359), -0.18, 750),
      PinballTarget(Offset(195, 370), -0.05, 750),
    ],
    rollovers: [Offset(133, 145), Offset(190, 124), Offset(248, 147)],
  ),
  PinballTableId.moonfallSanctuary => const PlayfieldPlan(
    shots: [
      PinballShot(
        name: 'LUNAR LOOP',
        type: ShotType.orbit,
        score: 2500,
        points: [
          Offset(97, 470),
          Offset(57, 314),
          Offset(73, 154),
          Offset(185, 99),
          Offset(300, 166),
          Offset(304, 384),
        ],
      ),
      PinballShot(
        name: 'ECLIPSE RAMP',
        type: ShotType.raisedRamp,
        score: 4200,
        points: [
          Offset(283, 414),
          Offset(245, 288),
          Offset(197, 212),
          Offset(112, 267),
          Offset(105, 466),
        ],
      ),
    ],
    targets: [
      PinballTarget(Offset(242, 345), 0.2, 900),
      PinballTarget(Offset(263, 365), 0.4, 900),
      PinballTarget(Offset(283, 383), 0.6, 900),
    ],
    rollovers: [Offset(114, 155), Offset(170, 122), Offset(235, 147)],
  ),
  PinballTableId.nebulaTempest => const PlayfieldPlan(
    shots: [
      PinballShot(
        name: 'STORM ORBIT',
        type: ShotType.orbit,
        score: 2750,
        points: [
          Offset(98, 425),
          Offset(60, 215),
          Offset(149, 105),
          Offset(262, 110),
          Offset(326, 223),
          Offset(290, 420),
        ],
      ),
      PinballShot(
        name: 'ION RAMP',
        type: ShotType.raisedRamp,
        score: 3500,
        points: [
          Offset(113, 480),
          Offset(157, 309),
          Offset(230, 232),
          Offset(282, 328),
          Offset(285, 477),
        ],
      ),
    ],
    targets: [
      PinballTarget(Offset(157, 380), 0.2, 650),
      PinballTarget(Offset(197, 396), 0, 650),
      PinballTarget(Offset(239, 381), -0.2, 650),
    ],
    rollovers: [Offset(145, 142), Offset(198, 130), Offset(252, 142)],
  ),
  PinballTableId.circuitVelocity => const PlayfieldPlan(
    shots: [
      PinballShot(
        name: 'EXPRESS ORBIT',
        type: ShotType.orbit,
        score: 2700,
        points: [
          Offset(87, 468),
          Offset(58, 275),
          Offset(116, 112),
          Offset(255, 105),
          Offset(319, 280),
          Offset(291, 461),
        ],
      ),
      PinballShot(
        name: 'OVERCLOCK RAMP',
        type: ShotType.raisedRamp,
        score: 4500,
        points: [
          Offset(288, 391),
          Offset(255, 225),
          Offset(197, 174),
          Offset(142, 294),
          Offset(126, 488),
        ],
      ),
    ],
    targets: [
      PinballTarget(Offset(175, 331), -0.34, 800),
      PinballTarget(Offset(199, 350), 0, 800),
      PinballTarget(Offset(225, 333), 0.34, 800),
    ],
    rollovers: [Offset(123, 140), Offset(192, 112), Offset(260, 140)],
  ),
  PinballTableId.quantumGrid => const PlayfieldPlan(
    shots: [
      PinballShot(
        name: 'PHASE CIRCUIT',
        type: ShotType.orbit,
        score: 3000,
        points: [
          Offset(287, 463),
          Offset(317, 293),
          Offset(282, 137),
          Offset(156, 106),
          Offset(73, 232),
          Offset(96, 435),
        ],
      ),
      PinballShot(
        name: 'RELAY OVERPASS',
        type: ShotType.raisedRamp,
        score: 3900,
        points: [
          Offset(114, 391),
          Offset(145, 248),
          Offset(202, 188),
          Offset(276, 288),
          Offset(278, 491),
        ],
      ),
    ],
    targets: [
      PinballTarget(Offset(225, 388), 0.28, 850),
      PinballTarget(Offset(243, 410), 0.4, 850),
      PinballTarget(Offset(258, 432), 0.5, 850),
    ],
    rollovers: [Offset(132, 152), Offset(194, 125), Offset(255, 150)],
  ),
  PinballTableId.reactorRush => const PlayfieldPlan(
    shots: [
      PinballShot(
        name: 'REACTOR ORBIT',
        type: ShotType.orbit,
        score: 2900,
        points: [
          Offset(98, 431),
          Offset(60, 241),
          Offset(122, 109),
          Offset(264, 113),
          Offset(318, 245),
          Offset(291, 429),
        ],
      ),
      PinballShot(
        name: 'COOLANT RAMP',
        type: ShotType.raisedRamp,
        score: 4800,
        points: [
          Offset(287, 481),
          Offset(244, 296),
          Offset(207, 208),
          Offset(142, 280),
          Offset(113, 478),
        ],
      ),
    ],
    targets: [
      PinballTarget(Offset(147, 356), -0.25, 1000),
      PinballTarget(Offset(195, 378), 0, 1000),
      PinballTarget(Offset(245, 350), 0.25, 1000),
    ],
    rollovers: [Offset(128, 142), Offset(194, 119), Offset(257, 142)],
  ),
  PinballTableId.grandMechanism => const PlayfieldPlan(
    shots: [
      PinballShot(
        name: 'GEARWORK ORBIT',
        type: ShotType.orbit,
        score: 3000,
        points: [
          Offset(90, 461),
          Offset(59, 256),
          Offset(115, 119),
          Offset(248, 104),
          Offset(317, 247),
          Offset(289, 436),
        ],
      ),
      PinballShot(
        name: 'ESCAPEMENT RAMP',
        type: ShotType.raisedRamp,
        score: 4250,
        points: [
          Offset(283, 424),
          Offset(264, 300),
          Offset(200, 185),
          Offset(137, 301),
          Offset(115, 489),
        ],
      ),
    ],
    targets: [
      PinballTarget(Offset(160, 358), -0.23, 750),
      PinballTarget(Offset(188, 375), 0, 750),
      PinballTarget(Offset(216, 357), 0.24, 750),
    ],
    rollovers: [Offset(127, 140), Offset(193, 120), Offset(254, 142)],
  ),
  PinballTableId.chronoCitadel => const PlayfieldPlan(
    shots: [
      PinballShot(
        name: 'CITADEL OUTER LOOP',
        type: ShotType.orbit,
        score: 3000,
        points: [
          Offset(295, 468),
          Offset(318, 277),
          Offset(251, 109),
          Offset(115, 106),
          Offset(63, 252),
          Offset(105, 449),
        ],
      ),
      PinballShot(
        name: 'BELL TOWER RAMP',
        type: ShotType.raisedRamp,
        score: 4700,
        points: [
          Offset(110, 480),
          Offset(145, 258),
          Offset(207, 211),
          Offset(266, 300),
          Offset(290, 457),
        ],
      ),
    ],
    targets: [
      PinballTarget(Offset(233, 357), 0.15, 900),
      PinballTarget(Offset(256, 373), 0.33, 900),
      PinballTarget(Offset(278, 395), 0.45, 900),
    ],
    rollovers: [Offset(130, 140), Offset(199, 125), Offset(265, 142)],
  ),
  PinballTableId.brassLabyrinth => const PlayfieldPlan(
    shots: [
      PinballShot(
        name: 'HIDDEN ORBIT',
        type: ShotType.orbit,
        score: 3250,
        points: [
          Offset(89, 478),
          Offset(56, 310),
          Offset(104, 145),
          Offset(208, 102),
          Offset(312, 199),
          Offset(287, 432),
        ],
      ),
      PinballShot(
        name: 'CLOCK HAND RAMP',
        type: ShotType.raisedRamp,
        score: 4400,
        points: [
          Offset(289, 477),
          Offset(248, 298),
          Offset(190, 209),
          Offset(127, 292),
          Offset(112, 443),
        ],
      ),
    ],
    targets: [
      PinballTarget(Offset(133, 332), -0.3, 800),
      PinballTarget(Offset(163, 353), -0.12, 800),
      PinballTarget(Offset(192, 369), 0.1, 800),
    ],
    rollovers: [Offset(137, 143), Offset(198, 121), Offset(261, 142)],
  ),
};
