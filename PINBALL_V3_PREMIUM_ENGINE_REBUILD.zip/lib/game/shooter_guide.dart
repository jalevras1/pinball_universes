/// Pure-Dart plunger and shooter-channel model, independent of Flutter or
/// Flame. A tiny executable verifier can test the ball feed without a browser.
class ShooterGuideState {
  const ShooterGuideState({
    required this.x,
    required this.y,
    required this.vx,
    required this.vy,
    required this.arcTime,
    this.enteredPlayfield = false,
  });

  final double x;
  final double y;
  final double vx;
  final double vy;
  final double arcTime;
  final bool enteredPlayfield;
}

abstract final class ShooterGuide {
  static const double laneX = 352;
  static const double laneTop = 132;
  static const double dividerX = 336;
  static const double gravity = 670;
  static const double upperFeedDuration = 0.27;

  static double velocityForPull(double power) =>
      -(930 + power.clamp(0.0, 1.0).toDouble() * 490);

  static ShooterGuideState advance(
    ShooterGuideState state,
    double dt, {
    required double power,
  }) {
    final p = power.clamp(0.0, 1.0).toDouble();
    if (state.arcTime < 0) {
      final vy = state.vy + gravity * dt;
      final y = state.y + vy * dt;
      return ShooterGuideState(
        x: laneX,
        y: y,
        vx: 0,
        vy: vy,
        arcTime: y <= laneTop ? 0 : -1,
      );
    }
    final nextTime = state.arcTime + dt;
    final t = (nextTime / upperFeedDuration).clamp(0.0, 1.0).toDouble();
    final k = 1 - t;
    final x =
        laneX * k * k * k +
        366 * 3 * k * k * t +
        303 * 3 * k * t * t +
        305 * t * t * t;
    final y =
        132 * k * k * k +
        72 * 3 * k * k * t +
        88 * 3 * k * t * t +
        163 * t * t * t;
    return ShooterGuideState(
      x: x,
      y: y,
      vx: t >= 1 ? -(140 + p * 160) : 0,
      vy: t >= 1 ? 110 + p * 160 : 0,
      arcTime: t >= 1 ? -1 : nextTime,
      enteredPlayfield: t >= 1,
    );
  }
}
