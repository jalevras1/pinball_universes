import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;

import '../audio/pinball_audio.dart';
import 'machine_rules.dart';
import 'physics_contact.dart';
import 'playfield_plan.dart';
import 'shooter_guide.dart';
import 'table_data.dart';

const double _boardWidth = 400;
const double _boardHeight = 760;
const double _ballRadius = 7.5;
const Offset _leftPivot = Offset(127, 664);
const Offset _rightPivot = Offset(273, 664);

class PinballHud {
  const PinballHud({
    required this.score,
    required this.balls,
    required this.mode,
    required this.isReady,
    required this.isPaused,
    required this.isMultiball,
    required this.awardLabel,
    required this.objective,
  });

  final int score;
  final int balls;
  final String mode;
  final bool isReady;
  final bool isPaused;
  final bool isMultiball;
  final String awardLabel;
  final String objective;
}

class _Ball {
  _Ball(this.position, this.velocity);

  Offset position;
  Offset velocity;
  bool inShooter = false;
  bool isLaunching = false;
  double launchPower = 0.65;
  double launchArcTime = -1;
  int activeShot = -1;
  double shotTime = 0;
  double portalCooldown = 0;
  double spin = 0;
  final List<Offset> trail = <Offset>[];
  final Map<int, double> lastBumperHit = <int, double>{};
}

class _Segment {
  const _Segment(this.a, this.b);

  final Offset a;
  final Offset b;
  final double bounce = 0.84;
}

class _Bumper {
  const _Bumper(this.center, this.radius, this.value);

  final Offset center;
  final double radius;
  final int value;
}

class _Impact {
  _Impact(this.center, this.color, {this.size = 1});
  final Offset center;
  final Color color;
  final double duration = 0.32;
  final double size;
  double age = 0;
}

/// Pinball table with an isolated shooter channel and data-driven physical
/// mechanisms. Forge2D integration is the next physics milestone; V3 uses a
/// 240 Hz custom solver with moving flipper contact normals and ball spin.
class PinballGame extends FlameGame {
  PinballGame({required this.table, required this.onGameFinished, this.audio})
    : hud = ValueNotifier<PinballHud>(
        PinballHud(
          score: 0,
          balls: 3,
          mode: table.modeNames.first,
          isReady: true,
          isPaused: false,
          isMultiball: false,
          awardLabel: '',
          objective: 'COMPLETE TWO SHOTS',
        ),
      );

  final PinballTableInfo table;
  late final PlayfieldPlan _plan = playfieldFor(table);
  late final MachineRules _rules = MachineRules(table.id.name);
  final ValueChanged<int> onGameFinished;
  final PinballAudio? audio;
  final ValueNotifier<PinballHud> hud;
  final List<_Ball> _balls = <_Ball>[];
  final List<_Segment> _rails = <_Segment>[];
  final List<_Bumper> _bumpers = <_Bumper>[];
  final List<_Impact> _impacts = <_Impact>[];
  final Map<int, double> _bumperLastGlow = <int, double>{};
  final Map<int, double> _targetGlow = <int, double>{};
  final Map<int, double> _rolloverGlow = <int, double>{};
  final Set<int> _downTargets = <int>{};
  final Set<int> _litRollovers = <int>{};
  double _resetTargetBankAt = -1;
  double plungerCharge = 0;
  ui.Image? _ballSprite;
  ui.Image? _bumperSprite;
  ui.Image? _backplateSprite;
  ui.Image? _hazardSprite;
  ui.Image? _flipperSprite;
  bool _spritesReleased = false;

  bool leftPressed = false;
  bool rightPressed = false;
  bool _paused = false;
  bool _finished = false;
  bool _multiballAwarded = false;
  int _score = 0;
  int _ballsToPlay = 3;
  int _hits = 0;
  double _time = 0;
  double _accumulator = 0;
  double _leftLift = 0;
  double _rightLift = 0;
  double _leftAngularSpeed = 0;
  double _rightAngularSpeed = 0;
  double _cinematicTime = -1;
  double _shake = 0;
  double _scoreBoostUntil = 0;
  double _ballSaverUntil = 0;
  double _awardTextUntil = 0;
  double _lastRailImpact = -100;
  String _awardText = '';
  bool reducedMotion = false;

  @override
  Color backgroundColor() => const Color(0xFF02040C);

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _configureTable();
    _ballSprite = await _loadSprite('assets/gameplay/steel_ball.png', 128);
    _flipperSprite = await _loadSprite(
      'assets/gameplay_v3/flipper_pro.png',
      512,
    );
    _bumperSprite = await _loadSprite('assets/gameplay_v3/bumper_pro.png', 256);
    _backplateSprite = await _loadSprite(
      'assets/playfields_v2/${table.universe.name}.png',
      900,
    );
    final hazardAsset = switch (table.universe) {
      PinballUniverseId.celestial when table.variant == 0 =>
        'assets/gameplay/portal_celestial.png',
      PinballUniverseId.neon when table.variant == 2 =>
        'assets/gameplay/reactor_neon.png',
      PinballUniverseId.clockwork when table.variant != 1 =>
        'assets/gameplay/gear_clockwork.png',
      _ => null,
    };
    if (hazardAsset != null) {
      _hazardSprite = await _loadSprite(hazardAsset, 192);
    }
    if (_spritesReleased) return;
    _prepareBall();
  }

  Future<ui.Image?> _loadSprite(String asset, int targetWidth) async {
    try {
      final data = await rootBundle.load(asset);
      final codec = await ui.instantiateImageCodec(
        data.buffer.asUint8List(),
        targetWidth: targetWidth,
      );
      final frame = await codec.getNextFrame();
      codec.dispose();
      if (_spritesReleased) {
        frame.image.dispose();
        return null;
      }
      return frame.image;
    } catch (error) {
      // Keep playable fallbacks, but surface missing asset declarations in logs.
      debugPrint('PINBALL ASSET FAILED: $asset ($error)');
      return null;
    }
  }

  void releaseSprites() {
    _spritesReleased = true;
    _ballSprite?.dispose();
    _bumperSprite?.dispose();
    _backplateSprite?.dispose();
    _hazardSprite?.dispose();
    _flipperSprite?.dispose();
    _ballSprite = null;
    _bumperSprite = null;
    _backplateSprite = null;
    _hazardSprite = null;
    _flipperSprite = null;
  }

  void _configureTable() {
    // Outer wall, sloping inlanes, shooter divider, and drain guides.
    _rails.addAll(const <_Segment>[
      _Segment(Offset(31, 690), Offset(31, 116)),
      _Segment(Offset(31, 116), Offset(63, 57)),
      _Segment(Offset(63, 57), Offset(330, 57)),
      _Segment(Offset(330, 57), Offset(369, 109)),
      _Segment(Offset(369, 109), Offset(369, 695)),
      _Segment(Offset(336, 205), Offset(336, 695)),
      _Segment(Offset(369, 105), Offset(315, 145)),
      _Segment(Offset(35, 559), Offset(105, 631)),
      _Segment(Offset(365, 559), Offset(295, 631)),
      _Segment(Offset(31, 689), Offset(88, 716)),
      _Segment(Offset(369, 689), Offset(312, 716)),
      _Segment(Offset(76, 612), Offset(105, 652)),
      _Segment(Offset(324, 612), Offset(295, 652)),
    ]);
    final perimeterRailCount = _rails.length;

    switch (table.universe) {
      case PinballUniverseId.celestial:
        switch (table.variant) {
          case 0: // Orrery: central constellation-triangle layout.
            _bumpers.addAll(const <_Bumper>[
              _Bumper(Offset(112, 287), 22, 500),
              _Bumper(Offset(211, 250), 24, 700),
              _Bumper(Offset(289, 319), 21, 500),
            ]);
            _rails.addAll(const <_Segment>[
              _Segment(Offset(62, 181), Offset(147, 116)),
              _Segment(Offset(255, 117), Offset(320, 197)),
              _Segment(Offset(87, 439), Offset(160, 481)),
              _Segment(Offset(310, 439), Offset(242, 481)),
            ]);
          case 1: // Moonfall: asymmetrical lunar well field.
            _bumpers.addAll(const <_Bumper>[
              _Bumper(Offset(99, 214), 20, 500),
              _Bumper(Offset(296, 270), 22, 800),
              _Bumper(Offset(191, 422), 27, 1000),
            ]);
            _rails.addAll(const <_Segment>[
              _Segment(Offset(77, 181), Offset(124, 148)),
              _Segment(Offset(284, 154), Offset(325, 206)),
              _Segment(Offset(75, 358), Offset(123, 393)),
              _Segment(Offset(258, 479), Offset(309, 435)),
            ]);
          default: // Nebula: dense storm gates and four-way bumpers.
            _bumpers.addAll(const <_Bumper>[
              _Bumper(Offset(110, 210), 20, 450),
              _Bumper(Offset(281, 205), 20, 450),
              _Bumper(Offset(172, 329), 19, 650),
              _Bumper(Offset(276, 422), 19, 650),
            ]);
            _rails.addAll(const <_Segment>[
              _Segment(Offset(76, 137), Offset(165, 172)),
              _Segment(Offset(231, 176), Offset(313, 134)),
              _Segment(Offset(62, 454), Offset(128, 497)),
              _Segment(Offset(248, 503), Offset(324, 463)),
            ]);
        }
      case PinballUniverseId.neon:
        switch (table.variant) {
          case 0: // Velocity: center acceleration rail.
            _bumpers.addAll(const <_Bumper>[
              _Bumper(Offset(112, 218), 20, 600),
              _Bumper(Offset(285, 219), 20, 600),
              _Bumper(Offset(199, 339), 24, 850),
              _Bumper(Offset(106, 433), 16, 300),
              _Bumper(Offset(293, 433), 16, 300),
            ]);
            _rails.addAll(const <_Segment>[
              _Segment(Offset(77, 125), Offset(148, 186)),
              _Segment(Offset(322, 125), Offset(249, 186)),
              _Segment(Offset(87, 476), Offset(167, 517)),
              _Segment(Offset(312, 476), Offset(234, 517)),
            ]);
          case 1: // Quantum: diagonally offset phase-relay obstacles.
            _bumpers.addAll(const <_Bumper>[
              _Bumper(Offset(89, 245), 21, 600),
              _Bumper(Offset(287, 310), 23, 750),
              _Bumper(Offset(196, 472), 19, 500),
            ]);
            _rails.addAll(const <_Segment>[
              _Segment(Offset(87, 135), Offset(149, 194)),
              _Segment(Offset(257, 181), Offset(317, 119)),
              _Segment(Offset(66, 395), Offset(129, 435)),
              _Segment(Offset(273, 496), Offset(320, 453)),
            ]);
          default: // Reactor: perimeter targets around a core.
            _bumpers.addAll(const <_Bumper>[
              _Bumper(Offset(199, 275), 30, 1200),
              _Bumper(Offset(100, 371), 20, 500),
              _Bumper(Offset(301, 371), 20, 500),
              _Bumper(Offset(198, 494), 18, 650),
            ]);
            _rails.addAll(const <_Segment>[
              _Segment(Offset(85, 159), Offset(145, 140)),
              _Segment(Offset(254, 140), Offset(314, 159)),
              _Segment(Offset(80, 443), Offset(125, 465)),
              _Segment(Offset(275, 465), Offset(318, 443)),
            ]);
        }
      case PinballUniverseId.clockwork:
        switch (table.variant) {
          case 0: // Mechanism: classic trilateral gears.
            _bumpers.addAll(const <_Bumper>[
              _Bumper(Offset(197, 216), 28, 900),
              _Bumper(Offset(105, 332), 20, 500),
              _Bumper(Offset(293, 332), 20, 500),
            ]);
            _rails.addAll(const <_Segment>[
              _Segment(Offset(76, 164), Offset(152, 127)),
              _Segment(Offset(246, 127), Offset(319, 164)),
              _Segment(Offset(81, 462), Offset(150, 504)),
              _Segment(Offset(313, 462), Offset(248, 504)),
            ]);
          case 1: // Citadel: split upper lane, lower timed gate.
            _bumpers.addAll(const <_Bumper>[
              _Bumper(Offset(115, 208), 22, 500),
              _Bumper(Offset(286, 208), 22, 500),
              _Bumper(Offset(198, 365), 23, 850),
            ]);
            _rails.addAll(const <_Segment>[
              _Segment(Offset(77, 150), Offset(160, 198)),
              _Segment(Offset(240, 198), Offset(318, 150)),
              _Segment(Offset(83, 484), Offset(145, 528)),
              _Segment(Offset(251, 527), Offset(319, 483)),
            ]);
          default: // Labyrinth: offset passage walls and four targets.
            _bumpers.addAll(const <_Bumper>[
              _Bumper(Offset(112, 242), 19, 400),
              _Bumper(Offset(288, 241), 19, 400),
              _Bumper(Offset(110, 433), 19, 500),
              _Bumper(Offset(288, 430), 19, 500),
            ]);
            _rails.addAll(const <_Segment>[
              _Segment(Offset(65, 320), Offset(162, 347)),
              _Segment(Offset(242, 349), Offset(329, 320)),
              _Segment(Offset(62, 514), Offset(140, 536)),
              _Segment(Offset(268, 532), Offset(331, 509)),
            ]);
        }
    }
    // The first prototype attached unrelated floating sticks to each bumper
    // layout. They are neither plausible machine guides nor intentional shots.
    // Keep the perimeter/inlane geometry; V2's functional elevated shot paths,
    // retracting targets and kickers come from the shared playfield plan.
    _rails.removeRange(perimeterRailCount, _rails.length);
  }

  void _prepareBall() {
    if (_finished) return;
    _rules.beginBall();
    final ball = _Ball(const Offset(352, 665), Offset.zero)..inShooter = true;
    _balls.add(ball);
    plungerCharge = 0;
    _notifyHud();
  }

  /// Launch strength from the pull-and-release plunger, 0..1. The ball travels
  /// straight up the dedicated right shooter lane instead of into its divider.
  void launch({double strength = 0.65}) {
    if (_paused || _finished) return;
    var didLaunch = false;
    for (final ball in _balls) {
      if (!ball.inShooter) continue;
      ball.inShooter = false;
      ball.isLaunching = true;
      ball.launchPower = strength.clamp(0.0, 1.0).toDouble();
      ball.launchArcTime = -1;
      ball.velocity = Offset(0, ShooterGuide.velocityForPull(strength));
      didLaunch = true;
    }
    plungerCharge = 0;
    if (didLaunch) _ballSaverUntil = math.max(_ballSaverUntil, _time + 7);
    if (didLaunch && !reducedMotion) _cinematicTime = 0;
    if (didLaunch) _pulse(const Offset(352, 663), table.accent, size: 1.8);
    if (didLaunch) audio?.play(PinballSound.launch);
    _notifyHud();
  }

  void togglePause() {
    if (_finished) return;
    _paused = !_paused;
    _notifyHud();
  }

  void restart() {
    _balls.clear();
    _score = 0;
    _hits = 0;
    _ballsToPlay = 3;
    _finished = false;
    _paused = false;
    _multiballAwarded = false;
    _impacts.clear();
    _bumperLastGlow.clear();
    _downTargets.clear();
    _litRollovers.clear();
    _targetGlow.clear();
    _rolloverGlow.clear();
    _resetTargetBankAt = -1;
    _rules.reset();
    plungerCharge = 0;
    _cinematicTime = -1;
    _scoreBoostUntil = 0;
    _ballSaverUntil = 0;
    _awardTextUntil = 0;
    _awardText = '';
    _shake = 0;
    leftPressed = false;
    rightPressed = false;
    _prepareBall();
  }

  void _notifyHud() {
    if (_finished && hud.value.balls == 0) return;
    hud.value = PinballHud(
      score: _score,
      balls: _ballsToPlay,
      mode: table.modeNames[_rules.modeIndex],
      isReady: _balls.any((ball) => ball.inShooter),
      isPaused: _paused,
      isMultiball: _balls.length > 1,
      awardLabel: _awardTextUntil > _time ? _awardText : '',
      objective: _rules.objective,
    );
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (_paused || _finished) return;
    _accumulator += math.min(dt, 0.05);
    // At 240 Hz a 1,600 px/s ball advances <= 6.7 px per contact frame:
    // less than its diameter, preventing thin-rail tunnelling on fast shots.
    const step = 1 / 240;
    var steps = 0;
    while (_accumulator >= step && steps < 12) {
      _simulate(step);
      _accumulator -= step;
      steps++;
    }
  }

  void _simulate(double dt) {
    _time += dt;
    if (_resetTargetBankAt > 0 && _time >= _resetTargetBankAt) {
      _downTargets.clear();
      _resetTargetBankAt = -1;
    }
    if (_awardText.isNotEmpty && _time >= _awardTextUntil) {
      _awardText = '';
      _notifyHud();
    }
    if (_cinematicTime >= 0) {
      _cinematicTime += dt;
      if (_cinematicTime > 1.35) _cinematicTime = -1;
    }
    _shake = math.max(0.0, _shake - dt * 6);
    for (final impact in List<_Impact>.of(_impacts)) {
      impact.age += dt;
      if (impact.age >= impact.duration) _impacts.remove(impact);
    }
    final previousLeftLift = _leftLift;
    final previousRightLift = _rightLift;
    _leftLift = _approach(_leftLift, leftPressed ? 1 : 0, dt * 16);
    _rightLift = _approach(_rightLift, rightPressed ? 1 : 0, dt * 16);
    _leftAngularSpeed = -0.67 * (_leftLift - previousLeftLift) / dt;
    _rightAngularSpeed = 0.67 * (_rightLift - previousRightLift) / dt;

    for (final ball in List<_Ball>.of(_balls)) {
      if (ball.inShooter) continue;
      if (ball.isLaunching) {
        _advanceShooter(ball, dt);
        _recordTrail(ball);
        continue;
      }
      if (ball.activeShot >= 0) {
        _advanceShot(ball, dt);
        _recordTrail(ball);
        continue;
      }
      ball.portalCooldown = math.max(0.0, ball.portalCooldown - dt);
      ball.velocity = Offset(
        ball.velocity.dx * 0.9994,
        ball.velocity.dy + 670 * dt,
      );
      ball.spin *= 0.998;
      final speed = ball.velocity.distance;
      if (speed > 1600) ball.velocity = ball.velocity * (1600 / speed);
      ball.position += ball.velocity * dt;

      for (final rail in _rails) {
        _collideSegment(ball, rail.a, rail.b, rail.bounce);
      }
      _collideFlipper(ball, left: true);
      _collideFlipper(ball, left: false);

      for (var i = 0; i < _bumpers.length; i++) {
        final bumper = _bumpers[i];
        final delta = ball.position - bumper.center;
        final limit = bumper.radius + _ballRadius;
        if (delta.distance >= limit) continue;
        final normal =
            delta.distance < 0.001
                ? const Offset(0, -1)
                : delta / delta.distance;
        ball.position = bumper.center + normal * limit;
        final dot = _dot(ball.velocity, normal);
        ball.velocity -= normal * (2.0 * math.min(0.0, dot));
        ball.velocity += normal * 270;
        if (_time - (ball.lastBumperHit[i] ?? -100) > 0.12) {
          ball.lastBumperHit[i] = _time;
          _bumperLastGlow[i] = _time;
          _pulse(bumper.center, table.secondary, size: 1.6);
          _shake = reducedMotion ? 0.0 : math.max(_shake, 0.16);
          audio?.play(switch (table.universe) {
            PinballUniverseId.celestial => PinballSound.bumperCelestial,
            PinballUniverseId.neon => PinballSound.bumperNeon,
            PinballUniverseId.clockwork => PinballSound.bumperClockwork,
          });
          _registerHit(bumper.value);
        }
      }
      _hitSlingshots(ball);
      _hitTargets(ball);
      _hitRollovers(ball);
      _tryShots(ball);
      if (ball.activeShot < 0) _specialBehavior(ball);

      if (ball.position.dy > 745 ||
          ball.position.dx < -50 ||
          ball.position.dx > 450) {
        _balls.remove(ball);
        audio?.play(PinballSound.drain);
      }

      _recordTrail(ball);
    }

    if (_balls.isEmpty && !_finished) {
      if (_ballSaverUntil > _time) {
        _ballSaverUntil = 0;
        _announce('BALL SAVED', seconds: 1.8);
        audio?.play(PinballSound.award);
        _pulse(const Offset(200, 678), table.accent, size: 2.8);
        _prepareBall();
        return;
      }
      _ballsToPlay--;
      if (_ballsToPlay <= 0) {
        _finished = true;
        hud.value = PinballHud(
          score: _score,
          balls: 0,
          mode: table.modeNames.last,
          isReady: false,
          isPaused: false,
          isMultiball: false,
          awardLabel: '',
          objective: 'GAME OVER',
        );
        onGameFinished(_score);
      } else {
        _prepareBall();
      }
    }
  }

  void _recordTrail(_Ball ball) {
    ball.trail.add(ball.position);
    if (ball.trail.length > 7) ball.trail.removeAt(0);
  }

  void _advanceShooter(_Ball ball, double dt) {
    final next = ShooterGuide.advance(
      ShooterGuideState(
        x: ball.position.dx,
        y: ball.position.dy,
        vx: ball.velocity.dx,
        vy: ball.velocity.dy,
        arcTime: ball.launchArcTime,
      ),
      dt,
      power: ball.launchPower,
    );
    ball.position = Offset(next.x, next.y);
    ball.velocity = Offset(next.vx, next.vy);
    ball.launchArcTime = next.arcTime;
    if (next.enteredPlayfield) {
      ball.isLaunching = false;
      _pulse(ball.position, table.accent, size: 1.2);
      _score += 500; // successful full-lane entry; not a bumper hit
      if (ball.launchPower >= 0.62 && ball.launchPower <= 0.77) {
        _score += 3000;
        _announce('PRECISION SKILL SHOT +3000', seconds: 2.0);
        audio?.play(PinballSound.award);
      }
      _notifyHud();
    }
  }

  void _advanceShot(_Ball ball, double dt) {
    final shot = _plan.shots[ball.activeShot];
    ball.shotTime += dt;
    final t =
        (ball.shotTime / (shot.type == ShotType.orbit ? 0.92 : 0.72))
            .clamp(0.0, 1.0)
            .toDouble();
    ball.position = _shotPosition(shot.points, t);
    if (t < 1) return;
    ball.activeShot = -1;
    ball.shotTime = 0;
    ball.velocity = Offset(shot.returnLane.dx < 200 ? 135 : -135, 325);
    _announce('${shot.name} +${shot.score}', seconds: 1.7);
    audio?.play(PinballSound.award);
    _pulse(ball.position, table.secondary, size: 2.2);
    _registerHit(shot.score);
    _applyMachineEvent(
      shot.type == ShotType.orbit ? MachineEvent.orbit : MachineEvent.ramp,
    );
  }

  void _tryShots(_Ball ball) {
    if (ball.velocity.dy > -170 || ball.portalCooldown > 0) return;
    for (var i = 0; i < _plan.shots.length; i++) {
      if ((ball.position - _plan.shots[i].entrance).distance > 19) continue;
      ball.activeShot = i;
      ball.shotTime = 0;
      ball.position = _plan.shots[i].entrance;
      ball.portalCooldown = 0.65;
      audio?.play(PinballSound.gate);
      return;
    }
  }

  /// Smooth cubic guide with continuous position and tangent at every join.
  /// The ball follows the *same* guide that the player sees on the playfield.
  Offset _shotPosition(List<Offset> points, double t) {
    final count = points.length - 1;
    final fractionAlong = t.clamp(0.0, 1.0).toDouble() * count;
    final index = math.min(fractionAlong.floor(), count - 1);
    final fraction = fractionAlong - index;
    final from = points[index];
    final to = points[index + 1];
    final prior = points[math.max(index - 1, 0)];
    final after = points[math.min(index + 2, count)];
    final control1 = from + (to - prior) * (1 / 6);
    final control2 = to - (after - from) * (1 / 6);
    final k = 1 - fraction;
    return from * (k * k * k) +
        control1 * (3 * k * k * fraction) +
        control2 * (3 * k * fraction * fraction) +
        to * (fraction * fraction * fraction);
  }

  void _hitSlingshots(_Ball ball) {
    for (final left in <bool>[true, false]) {
      final a = left ? const Offset(76, 572) : const Offset(324, 572);
      final b = left ? const Offset(149, 619) : const Offset(251, 619);
      if (!_collideSegment(ball, a, b, 0.82, width: 6)) continue;
      if (ball.portalCooldown > 0) continue;
      ball.velocity = Offset(left ? 320 : -320, -500);
      ball.portalCooldown = 0.22;
      _pulse((a + b) / 2, table.secondary, size: 1.2);
      audio?.play(PinballSound.flipper);
      _registerHit(150);
    }
  }

  void _hitTargets(_Ball ball) {
    for (var i = 0; i < _plan.targets.length; i++) {
      if (_downTargets.contains(i)) continue;
      final target = _plan.targets[i];
      final vector =
          Offset(math.cos(target.angle), math.sin(target.angle)) * 11;
      if (!_collideSegment(
        ball,
        target.center - vector,
        target.center + vector,
        0.7,
        width: 3,
      ))
        continue;
      if (ball.portalCooldown > 0) continue;
      ball.portalCooldown = 0.12;
      _downTargets.add(i);
      _targetGlow[i] = _time;
      _pulse(target.center, table.accent, size: 1.0);
      audio?.play(PinballSound.gate);
      _registerHit(target.score);
      if (_downTargets.length == _plan.targets.length) {
        _resetTargetBankAt = _time + 2.8;
        _announce('TARGET BANK COMPLETE +5000', seconds: 2.1);
        audio?.play(PinballSound.jackpot);
        _score += 5000;
        _notifyHud();
        _applyMachineEvent(MachineEvent.targetBank);
      }
    }
  }

  void _hitRollovers(_Ball ball) {
    for (var i = 0; i < _plan.rollovers.length; i++) {
      final center = _plan.rollovers[i];
      if ((ball.position - center).distance > 13 ||
          _time - (_rolloverGlow[i] ?? -100) < 0.6)
        continue;
      _rolloverGlow[i] = _time;
      _litRollovers.add(i);
      _pulse(center, table.accent, size: 0.7);
      _registerHit(500);
      if (_litRollovers.length == 3) {
        _litRollovers.clear();
        _score += 3000;
        _announce('LANES COMPLETED +3000', seconds: 1.9);
        audio?.play(PinballSound.award);
        _notifyHud();
        _applyMachineEvent(MachineEvent.rolloverBank);
      }
    }
  }

  void _specialBehavior(_Ball ball) {
    switch (table.universe) {
      case PinballUniverseId.celestial:
        if (table.variant == 0) {
          _portal(ball, const Offset(111, 404), const Offset(289, 156));
        } else if (table.variant == 1) {
          _gravityWell(ball, const Offset(114, 359), radius: 115, pull: 255);
          _gravityWell(ball, const Offset(285, 187), radius: 80, pull: 160);
        } else {
          final x = 200.0 + 52 * math.sin(_time * 1.6);
          _movingBarrier(ball, Offset(x - 34, 438), Offset(x + 34, 438));
        }
      case PinballUniverseId.neon:
        if (table.variant == 0) {
          if (ball.position.dy > 390 &&
              ball.position.dy < 402 &&
              ball.position.dx > 150 &&
              ball.position.dx < 250 &&
              ball.velocity.dy > 30) {
            ball.velocity = Offset(ball.velocity.dx * 1.15, -740);
            if (ball.portalCooldown == 0) {
              ball.portalCooldown = 0.55;
              _pulse(const Offset(200, 391), table.accent, size: 2);
              audio?.play(PinballSound.boost);
              _registerHit(350);
            }
          }
        } else if (table.variant == 1) {
          _portal(ball, const Offset(100, 392), const Offset(280, 147));
        } else {
          _gravityWell(ball, const Offset(200, 297), radius: 110, pull: 190);
          final x = 200.0 + 46 * math.sin(_time * 1.9);
          _movingBarrier(ball, Offset(x - 22, 474), Offset(x + 22, 474));
        }
      case PinballUniverseId.clockwork:
        if (table.variant == 0) {
          _movingGear(ball, Offset(200 + 36 * math.sin(_time * 1.5), 433));
        } else if (table.variant == 1) {
          if (_time % 4.8 < 2.8) {
            _movingBarrier(
              ball,
              const Offset(127, 457),
              const Offset(273, 457),
            );
          }
        } else {
          final shift = 38 * math.sin(_time * 1.22);
          _movingBarrier(
            ball,
            Offset(86 + shift, 375),
            Offset(170 + shift, 375),
          );
          _movingGear(ball, Offset(255 - shift * 0.6, 471));
        }
    }
  }

  void _portal(_Ball ball, Offset entrance, Offset exit) {
    if (ball.portalCooldown > 0 || (ball.position - entrance).distance > 23)
      return;
    ball.position = exit;
    ball.velocity = const Offset(-120, -500);
    ball.portalCooldown = 1.1;
    _pulse(entrance, table.secondary, size: 2.3);
    _pulse(exit, table.accent, size: 2.3);
    audio?.play(PinballSound.portal);
    _registerHit(1200);
  }

  void _gravityWell(
    _Ball ball,
    Offset center, {
    required double radius,
    required double pull,
  }) {
    final delta = center - ball.position;
    final distance = delta.distance;
    if (distance < 18 || distance > radius) return;
    final factor = 1 - distance / radius;
    ball.velocity += delta / distance * (pull * factor / 120);
    if (distance < radius * 0.35) audio?.play(PinballSound.gravity);
  }

  void _movingBarrier(_Ball ball, Offset a, Offset b) {
    if (!_collideSegment(ball, a, b, 0.95, width: 5)) return;
    if (ball.portalCooldown > 0) return;
    ball.portalCooldown = 0.45;
    _pulse((a + b) / 2, table.secondary, size: 1.4);
    audio?.play(PinballSound.gate);
    _registerHit(450);
  }

  void _movingGear(_Ball ball, Offset center) {
    final delta = ball.position - center;
    final distance = delta.distance;
    if (distance > 21 + _ballRadius || distance < 0.1) return;
    final normal = delta / distance;
    ball.position = center + normal * (21 + _ballRadius);
    ball.velocity = normal * 550;
    if (ball.portalCooldown > 0) return;
    ball.portalCooldown = 0.4;
    _pulse(center, table.secondary, size: 1.6);
    audio?.play(PinballSound.gear);
    _registerHit(400);
  }

  void _registerHit(int points) {
    _score += _scoreBoostUntil > _time ? points * 2 : points;
    _hits++;
    if (_hits == 5) {
      _scoreBoostUntil = _time + 13;
      _announce('2X SCORE • 13 SEC', seconds: 3);
      audio?.play(PinballSound.boost);
      _pulse(const Offset(200, 375), table.accent, size: 3);
    } else if (_hits == 9) {
      _ballSaverUntil = _time + 17;
      _announce('BALL SAVE ACTIVATED', seconds: 3);
      audio?.play(PinballSound.award);
      _pulse(const Offset(200, 663), table.secondary, size: 2.8);
    } else if (_hits == 17) {
      _ballsToPlay++;
      _announce('EXTRA BALL AWARDED', seconds: 3);
      audio?.play(PinballSound.extraBall);
      _pulse(const Offset(200, 385), table.accent, size: 4);
    } else if (_hits == 24) {
      _score += 10000;
      _announce('SUPER JACKPOT +10,000', seconds: 3.5);
      audio?.play(PinballSound.jackpot);
      _pulse(const Offset(200, 300), table.secondary, size: 5);
      _shake = reducedMotion ? 0 : 0.45;
    }
    _notifyHud();
  }

  void _applyMachineEvent(MachineEvent event) {
    final award = _rules.record(event, _time);
    _score += award.bonus;
    if (award.ballSaveSeconds > 0) {
      _ballSaverUntil = math.max(
        _ballSaverUntil,
        _time + award.ballSaveSeconds,
      );
    }
    if (award.message.isNotEmpty) {
      _announce(award.message, seconds: 2.2);
      audio?.play(
        award.message.contains('JACKPOT')
            ? PinballSound.jackpot
            : PinballSound.award,
      );
    }
    if (award.startMultiball && !_multiballAwarded) {
      _multiballAwarded = true;
      _balls.add(_Ball(const Offset(182, 182), const Offset(-190, 320)));
      _balls.add(_Ball(const Offset(222, 182), const Offset(190, 320)));
      _announce('3-BALL MULTIBALL', seconds: 3);
      audio?.play(PinballSound.multiball);
      _pulse(const Offset(200, 220), table.accent, size: 3.2);
    }
    _notifyHud();
  }

  void _announce(String text, {double seconds = 2}) {
    _awardText = text;
    _awardTextUntil = _time + seconds;
  }

  void _pulse(Offset point, Color color, {double size = 1}) {
    // Restrained and bounded: never flood the screen during multiball.
    if (_impacts.length >= 28) _impacts.removeAt(0);
    _impacts.add(_Impact(point, color, size: size));
  }

  void _collideFlipper(_Ball ball, {required bool left}) {
    final a = left ? _leftPivot : _rightPivot;
    final lift = left ? _leftLift : _rightLift;
    final radians = left ? -0.19 - lift * 0.67 : math.pi + 0.19 + lift * 0.67;
    final b = a + Offset(math.cos(radians) * 78, math.sin(radians) * 78);
    final contact = ContactPhysics.capsule(
      ball: ContactBall(
        x: ball.position.dx,
        y: ball.position.dy,
        vx: ball.velocity.dx,
        vy: ball.velocity.dy,
        spin: ball.spin,
      ),
      ax: a.dx,
      ay: a.dy,
      bx: b.dx,
      by: b.dy,
      radius: _ballRadius + 9,
      restitution: 0.70,
      friction: 0.32,
      angularSpeed: left ? _leftAngularSpeed : _rightAngularSpeed,
      pivotX: a.dx,
      pivotY: a.dy,
    );
    if (!contact.collided) return;
    ball.position = Offset(contact.ball.x, contact.ball.y);
    ball.velocity = Offset(contact.ball.vx, contact.ball.vy);
    ball.spin = contact.ball.spin;
    if (contact.normalImpulse > 140 &&
        _time - (ball.lastBumperHit[left ? -1 : -2] ?? -100) > 0.06) {
      ball.lastBumperHit[left ? -1 : -2] = _time;
      _score += 10;
      audio?.play(PinballSound.flipper);
      _pulse(ball.position, table.accent, size: 0.40);
      _notifyHud();
    }
  }

  bool _collideSegment(
    _Ball ball,
    Offset a,
    Offset b,
    double bounce, {
    double width = 0,
  }) {
    final contact = ContactPhysics.capsule(
      ball: ContactBall(
        x: ball.position.dx,
        y: ball.position.dy,
        vx: ball.velocity.dx,
        vy: ball.velocity.dy,
        spin: ball.spin,
      ),
      ax: a.dx,
      ay: a.dy,
      bx: b.dx,
      by: b.dy,
      radius: _ballRadius + width,
      restitution: bounce,
      friction: width > 0 ? 0.28 : 0.12,
    );
    if (!contact.collided) return false;
    ball.position = Offset(contact.ball.x, contact.ball.y);
    ball.velocity = Offset(contact.ball.vx, contact.ball.vy);
    ball.spin = contact.ball.spin;
    if (contact.normalImpulse > 300 && _time - _lastRailImpact > 0.10) {
      _lastRailImpact = _time;
      _pulse(ball.position, table.accent, size: 0.75);
      audio?.play(PinballSound.rail);
    }
    return true;
  }

  double _dot(Offset a, Offset b) => a.dx * b.dx + a.dy * b.dy;

  double _approach(double current, double target, double maxDelta) =>
      current + (target - current).clamp(-maxDelta, maxDelta).toDouble();

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final viewWidth = size.x;
    final viewHeight = size.y;
    if (viewWidth <= 0 || viewHeight <= 0) return;
    final scale = math.min(viewWidth / _boardWidth, viewHeight / _boardHeight);
    var zoom = 1.0;
    var focus = const Offset(200, 380);
    // Cinematic plunger close-up -> short ball follow -> full-field reveal.
    // The shot never pauses physics or prevents two-finger flipper input.
    if (_cinematicTime >= 0 && !reducedMotion) {
      final blend =
          _cinematicTime < 0.35
              ? 1.0
              : (1 - (_cinematicTime - 0.35) / 1.0).clamp(0.0, 1.0).toDouble();
      zoom = 1 + 0.34 * blend * blend;
      if (_balls.isNotEmpty) {
        focus = Offset.lerp(focus, _balls.first.position, 0.82 * blend)!;
      }
    }
    canvas.save();
    canvas.clipRect(Rect.fromLTWH(0, 0, viewWidth, viewHeight));
    canvas.translate(viewWidth / 2, viewHeight / 2);
    canvas.scale(scale * zoom);
    canvas.translate(-focus.dx, -focus.dy);
    if (_shake > 0 && !reducedMotion) {
      canvas.translate(
        math.sin(_time * 63) * _shake * 2.2,
        math.cos(_time * 71) * _shake * 2.2,
      );
    }
    _renderBoard(canvas);
    canvas.restore();
  }

  void _renderBoard(Canvas c) {
    final board = RRect.fromRectAndRadius(
      const Rect.fromLTWH(12, 12, 376, 736),
      const Radius.circular(26),
    );
    c.drawRRect(
      board,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[table.base, const Color(0xFF04050A), table.base],
        ).createShader(const Rect.fromLTWH(0, 0, 400, 760)),
    );
    final backplate = _backplateSprite;
    if (backplate != null) {
      // Original high-detail 2D scene, deliberately *without* physical parts.
      // Real colliders and animated targets are rendered above this layer.
      const dest = Rect.fromLTWH(12, 12, 376, 736);
      // The new painted underlay is a precisely authored full-board print.
      // Use its complete frame rather than cropping off its outer decoration.
      final source = Rect.fromLTWH(
        0,
        0,
        backplate.width.toDouble(),
        backplate.height.toDouble(),
      );
      c.save();
      c.clipRRect(board);
      c.drawImageRect(
        backplate,
        source,
        dest,
        Paint()..filterQuality = FilterQuality.medium,
      );
      // A fine clearcoat tint protects shot readability over printed detail.
      c.drawRect(
        dest,
        Paint()
          ..shader = const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: <Color>[
              Color(0x2000030A),
              Color(0x0C000108),
              Color(0x38000209),
            ],
          ).createShader(dest),
      );
      c.restore();
    }
    c.drawRRect(
      board,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..color = const Color(0xFF232D38),
    );
    c.drawRRect(
      board,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = const Color(0xFF9CA7B1).withValues(alpha: 0.75),
    );

    if (_backplateSprite == null) _drawTableDecor(c);
    _drawPhysicalHardware(c);
    _drawSpecialHardware(c);

    for (final rail in _rails) {
      _drawMetalRail(c, rail.a, rail.b);
    }
    for (var i = 0; i < _bumpers.length; i++) {
      final bumper = _bumpers[i];
      final sprite = _bumperSprite;
      c.drawCircle(
        bumper.center + const Offset(2, 4),
        bumper.radius * 1.27,
        Paint()..color = Colors.black.withValues(alpha: 0.66),
      );
      c.drawCircle(
        bumper.center,
        bumper.radius + 3,
        Paint()..color = const Color(0xFF717D89),
      );
      c.drawCircle(
        bumper.center,
        bumper.radius + 0.5,
        Paint()..color = const Color(0xFF151E2A),
      );
      if (sprite != null) {
        _drawCenteredSprite(c, sprite, bumper.center, bumper.radius * 1.14);
      } else {
        _glowCircle(c, bumper.center, bumper.radius, table.secondary);
        _glowCircle(c, bumper.center, bumper.radius * 0.48, table.accent);
      }
      final sinceHit = _time - (_bumperLastGlow[i] ?? -100);
      if (sinceHit < 0.30) {
        final strength = (1 - sinceHit / 0.30).clamp(0.0, 1.0).toDouble();
        _drawRing(
          c,
          bumper.center,
          bumper.radius + 7 + sinceHit * 45,
          table.accent.withValues(alpha: strength * 0.8),
          4,
        );
      }
    }

    _drawImpacts(c);

    _drawFlipper(c, _leftPivot, true, _leftLift);
    _drawFlipper(c, _rightPivot, false, _rightLift);

    // The mechanical shooter and its moving spring handle are drawn by
    // _drawPhysicalHardware, not as an overlaid play button.

    for (final ball in _balls) {
      for (var i = 0; i < ball.trail.length; i++) {
        final alpha = (i + 1) / (ball.trail.length + 1) * 0.10;
        c.drawCircle(
          ball.trail[i],
          1.5 + alpha * 8,
          Paint()..color = const Color(0xFFE2EDF5).withValues(alpha: alpha),
        );
      }
      c.drawCircle(
        ball.position + const Offset(2, 3),
        _ballRadius + 2,
        Paint()..color = Colors.black.withValues(alpha: 0.70),
      );
      final sprite = _ballSprite;
      if (sprite != null) {
        _drawCenteredSprite(c, sprite, ball.position, _ballRadius * 1.35);
      } else {
        c.drawCircle(
          ball.position,
          _ballRadius,
          Paint()
            ..shader = const RadialGradient(
              center: Alignment(-0.5, -0.6),
              colors: <Color>[
                Colors.white,
                Color(0xFFA8C8E0),
                Color(0xFF26344B),
              ],
            ).createShader(
              Rect.fromCircle(center: ball.position, radius: _ballRadius),
            ),
        );
        c.drawCircle(
          ball.position + const Offset(-2, -3),
          2.2,
          Paint()..color = Colors.white,
        );
      }
    }
  }

  void _drawCenteredSprite(
    Canvas canvas,
    ui.Image image,
    Offset center,
    double radius,
  ) {
    // Keeps circular bumpers round even when a source canvas is widescreen.
    final side = math.min(image.width, image.height).toDouble();
    final source = Rect.fromLTWH(
      (image.width - side) / 2,
      (image.height - side) / 2,
      side,
      side,
    );
    canvas.drawImageRect(
      image,
      source,
      Rect.fromCircle(center: center, radius: radius),
      Paint()..filterQuality = FilterQuality.high,
    );
  }

  void _drawRotatingSprite(
    Canvas canvas,
    ui.Image image,
    Offset center,
    double radius,
    double angle,
  ) {
    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.rotate(angle);
    _drawCenteredSprite(canvas, image, Offset.zero, radius);
    canvas.restore();
  }

  void _drawImpacts(Canvas c) {
    for (final impact in _impacts) {
      final progress = impact.age / impact.duration;
      final fading = (1 - progress).clamp(0.0, 1.0).toDouble();
      final radius = (7 + 30 * progress) * impact.size;
      c.drawCircle(
        impact.center,
        radius,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5 * fading
          ..color = impact.color.withValues(alpha: 0.58 * fading),
      );
      // Sparse radial spark lines: readable even during multiball.
      for (var i = 0; i < 7; i++) {
        final angle = i * (math.pi * 2 / 7);
        final inner =
            impact.center +
            Offset(
              math.cos(angle) * radius * 0.52,
              math.sin(angle) * radius * 0.52,
            );
        final outer =
            impact.center +
            Offset(
              math.cos(angle) * radius * 0.82,
              math.sin(angle) * radius * 0.82,
            );
        c.drawLine(
          inner,
          outer,
          Paint()
            ..strokeWidth = fading * 2
            ..strokeCap = StrokeCap.round
            ..color = impact.color.withValues(alpha: fading * 0.72),
        );
      }
    }
  }

  void _drawTableDecor(Canvas c) {
    switch (table.universe) {
      case PinballUniverseId.celestial:
        for (var i = 0; i < 24; i++) {
          final x = 43.0 + (i * 79 % 310);
          final y = 72.0 + (i * 137 % 555);
          c.drawCircle(
            Offset(x, y),
            1.2,
            Paint()..color = Colors.white.withValues(alpha: 0.6),
          );
        }
        _drawRing(c, const Offset(200, 163), 49, table.accent, 1.4);
        _drawRing(c, const Offset(200, 163), 38, table.secondary, 2);
        _drawRing(c, const Offset(200, 531), 52, table.accent, 1);
        for (var i = 0; i < 8; i++) {
          final angle = i * math.pi / 4 + _time * 0.17;
          final a =
              const Offset(200, 163) +
              Offset(math.cos(angle) * 32, math.sin(angle) * 32);
          final b =
              const Offset(200, 163) +
              Offset(math.cos(angle) * 48, math.sin(angle) * 48);
          _glowLine(c, a, b, table.secondary, 1.2);
        }
        if (table.variant == 0) {
          final sprite = _hazardSprite;
          if (sprite != null) {
            _drawRotatingSprite(
              c,
              sprite,
              const Offset(111, 404),
              28,
              _time * 0.32,
            );
            _drawRotatingSprite(
              c,
              sprite,
              const Offset(289, 156),
              28,
              -_time * 0.28,
            );
          } else {
            _drawRing(c, const Offset(111, 404), 22, table.secondary, 3);
            _drawRing(c, const Offset(289, 156), 22, table.accent, 3);
          }
        } else if (table.variant == 1) {
          _drawRing(c, const Offset(114, 359), 72, table.secondary, 1.5);
          _drawRing(c, const Offset(285, 187), 41, table.accent, 2);
        } else if (table.variant == 2) {
          final x = 200.0 + 52 * math.sin(_time * 1.6);
          _glowLine(
            c,
            Offset(x - 34, 438),
            Offset(x + 34, 438),
            table.secondary,
            7,
          );
        }
      case PinballUniverseId.neon:
        for (var i = 0; i < 14; i++) {
          final y = 99.0 + i * 39;
          _glowLine(
            c,
            Offset(53, y),
            Offset(324, y),
            table.accent.withValues(alpha: 0.16),
            0.6,
          );
        }
        for (var i = 0; i < 7; i++) {
          final x = 63.0 + i * 42;
          _glowLine(
            c,
            Offset(x, 84),
            Offset(x, 621),
            table.secondary.withValues(alpha: 0.13),
            0.6,
          );
        }
        _drawRing(c, const Offset(200, 391), 46, table.secondary, 3);
        _drawRing(c, const Offset(200, 391), 28, table.accent, 2);
        _glowLine(
          c,
          const Offset(144, 390),
          const Offset(256, 390),
          table.secondary,
          5,
        );
        if (table.variant == 1) {
          _drawRing(c, const Offset(100, 392), 24, table.secondary, 3);
          _drawRing(c, const Offset(280, 147), 24, table.accent, 3);
        } else if (table.variant == 2) {
          if (_hazardSprite case final reactor?) {
            _drawCenteredSprite(c, reactor, const Offset(200, 297), 47);
          }
          _drawRing(c, const Offset(200, 297), 74, table.accent, 2);
          final x = 200.0 + 46 * math.sin(_time * 1.9);
          _glowLine(
            c,
            Offset(x - 22, 474),
            Offset(x + 22, 474),
            table.secondary,
            6,
          );
        }
      case PinballUniverseId.clockwork:
        for (final center in <Offset>[
          const Offset(200, 154),
          const Offset(97, 474),
          const Offset(298, 475),
        ]) {
          final radius = center.dx == 200 ? 48.0 : 32.0;
          _drawRing(c, center, radius, table.accent, 2.5);
          _drawRing(c, center, radius - 13, table.secondary, 1.2);
          for (var i = 0; i < 12; i++) {
            final angle = i * math.pi / 6 + _time * 0.14;
            _glowLine(
              c,
              center +
                  Offset(
                    math.cos(angle) * (radius - 3),
                    math.sin(angle) * (radius - 3),
                  ),
              center +
                  Offset(
                    math.cos(angle) * (radius + 6),
                    math.sin(angle) * (radius + 6),
                  ),
              table.accent,
              3,
            );
          }
        }
        if (table.variant == 0) {
          final center = Offset(200 + 36 * math.sin(_time * 1.5), 433);
          if (_hazardSprite case final gear?) {
            _drawRotatingSprite(c, gear, center, 23, _time * 1.9);
          } else {
            _drawRing(c, center, 21, table.secondary, 6);
          }
        } else if (table.variant == 1) {
          if (_time % 4.8 < 2.8) {
            _glowLine(
              c,
              const Offset(127, 457),
              const Offset(273, 457),
              table.accent,
              7,
            );
          }
        } else if (table.variant == 2) {
          final shift = 38 * math.sin(_time * 1.22);
          _glowLine(
            c,
            Offset(86 + shift, 375),
            Offset(170 + shift, 375),
            table.secondary,
            7,
          );
          final center = Offset(255 - shift * 0.6, 471);
          if (_hazardSprite case final gear?) {
            _drawRotatingSprite(c, gear, center, 23, -_time * 1.4);
          } else {
            _drawRing(c, center, 21, table.accent, 3);
          }
        }
    }
  }

  /// Under-glass physical mechanisms are drawn above the illustrated playfield.
  /// Every ramp/target/rollover below comes from the same live shot map used by
  /// the simulator, so the table cannot advertise an imaginary obstacle.
  void _drawPhysicalHardware(Canvas c) {
    final metal =
        table.universe == PinballUniverseId.clockwork
            ? const Color(0xFFCCB18A)
            : const Color(0xFFD9E5EC);
    final rubber =
        table.universe == PinballUniverseId.neon
            ? const Color(0xFF213A48)
            : const Color(0xFF191C25);

    // Black playfield inserts, lighting rings, and bank mounting plates.
    for (final shot in _plan.shots) {
      final path = Path()..moveTo(shot.entrance.dx, shot.entrance.dy);
      for (var section = 0; section < shot.points.length - 1; section++) {
        // Render a smooth cubic which matches _shotPosition's physics track.
        final from = shot.points[section];
        final to = shot.points[section + 1];
        final prior = shot.points[math.max(0, section - 1)];
        final after =
            shot.points[math.min(shot.points.length - 1, section + 2)];
        final control1 = from + (to - prior) * (1 / 6);
        final control2 = to - (after - from) * (1 / 6);
        path.cubicTo(
          control1.dx,
          control1.dy,
          control2.dx,
          control2.dy,
          to.dx,
          to.dy,
        );
      }
      c.drawPath(
        path,
        Paint()
          ..strokeWidth = shot.type == ShotType.raisedRamp ? 20 : 14
          ..style = PaintingStyle.stroke
          ..strokeJoin = StrokeJoin.round
          ..strokeCap = StrokeCap.round
          ..color = Colors.black.withValues(alpha: 0.52),
      );
      c.drawPath(
        path,
        Paint()
          ..strokeWidth = shot.type == ShotType.raisedRamp ? 14 : 7
          ..style = PaintingStyle.stroke
          ..strokeJoin = StrokeJoin.round
          ..strokeCap = StrokeCap.round
          ..color =
              shot.type == ShotType.raisedRamp
                  ? const Color(0xFF3C4551).withValues(alpha: 0.88)
                  : const Color(0xFF141D28).withValues(alpha: 0.76),
      );
      c.drawPath(
        path,
        Paint()
          ..strokeWidth = shot.type == ShotType.raisedRamp ? 2.3 : 2.0
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round
          ..color = metal.withValues(alpha: 0.85),
      );
      c.drawCircle(
        shot.entrance,
        14,
        Paint()..color = const Color(0xFF04070B).withValues(alpha: 0.9),
      );
      c.drawCircle(
        shot.entrance,
        11,
        Paint()
          ..color = table.accent.withValues(alpha: 0.33)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
      // The entrance arrow is a real, hittable shot cue.
      final arrow =
          Path()
            ..moveTo(shot.entrance.dx - 4, shot.entrance.dy + 4)
            ..lineTo(shot.entrance.dx, shot.entrance.dy - 5)
            ..lineTo(shot.entrance.dx + 4, shot.entrance.dy + 4);
      c.drawPath(
        arrow,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..strokeCap = StrokeCap.round
          ..color = table.accent.withValues(alpha: 0.85),
      );
    }

    // Three switch/rollover lanes under the upper arch.
    for (var i = 0; i < _plan.rollovers.length; i++) {
      final center = _plan.rollovers[i];
      final glowing =
          _time - (_rolloverGlow[i] ?? -100) < 0.35 ||
          _litRollovers.contains(i);
      c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: center, width: 17, height: 28),
          const Radius.circular(7),
        ),
        Paint()..color = const Color(0xFF08101A).withValues(alpha: 0.85),
      );
      c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: center, width: 13, height: 23),
          const Radius.circular(6),
        ),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..color = glowing ? table.accent : metal.withValues(alpha: 0.55),
      );
      c.drawCircle(
        center,
        4,
        Paint()..color = glowing ? table.accent : const Color(0xFF4C5961),
      );
    }

    // Bank of three mechanically retracting rectangular drop targets.
    for (var i = 0; i < _plan.targets.length; i++) {
      final target = _plan.targets[i];
      final down = _downTargets.contains(i);
      c.save();
      c.translate(target.center.dx, target.center.dy);
      c.rotate(target.angle);
      final base = RRect.fromRectAndRadius(
        const Rect.fromLTWH(-13, -8, 26, 16),
        const Radius.circular(2),
      );
      c.drawRRect(base, Paint()..color = Colors.black.withValues(alpha: 0.80));
      c.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(-11, down ? 0 : -9, 22, down ? 5 : 16),
          const Radius.circular(2),
        ),
        Paint()..color = down ? const Color(0xFF464B4A) : metal,
      );
      if (!down) {
        c.drawRect(
          const Rect.fromLTWH(-6, -5, 12, 5),
          Paint()..color = table.secondary.withValues(alpha: 0.9),
        );
      }
      c.restore();
    }

    // Slingshot kickers: molded triangular rubber, ball-kicking steel posts.
    for (final left in <bool>[true, false]) {
      final points =
          left
              ? <Offset>[
                const Offset(75, 564),
                const Offset(155, 615),
                const Offset(97, 616),
              ]
              : <Offset>[
                const Offset(325, 564),
                const Offset(245, 615),
                const Offset(303, 616),
              ];
      final triangle =
          Path()
            ..moveTo(points.first.dx, points.first.dy)
            ..lineTo(points[1].dx, points[1].dy)
            ..lineTo(points[2].dx, points[2].dy)
            ..close();
      c.drawPath(
        triangle.shift(const Offset(2, 3)),
        Paint()..color = Colors.black.withValues(alpha: 0.67),
      );
      c.drawPath(triangle, Paint()..color = rubber.withValues(alpha: 0.93));
      c.drawPath(
        triangle,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4
          ..strokeJoin = StrokeJoin.round
          ..color = table.secondary.withValues(alpha: 0.75),
      );
      for (final point in points) {
        c.drawCircle(point, 5, Paint()..color = const Color(0xFF29323A));
        c.drawCircle(point - const Offset(1, 1), 2.5, Paint()..color = metal);
      }
    }

    // Spring-fed dedicated shooter channel at the right edge. The plunger
    // responds in real time to drag strength; it is not a giant floating UI.
    final lane = RRect.fromRectAndRadius(
      const Rect.fromLTWH(339, 204, 28, 495),
      const Radius.circular(11),
    );
    c.drawRRect(lane, Paint()..color = const Color(0xE9070B11));
    _drawMetalRail(c, const Offset(338, 202), const Offset(338, 696));
    _drawMetalRail(c, const Offset(370, 204), const Offset(370, 696));
    // Shooter knob, drawn beneath the queued ball and visible at all times.
    final handleY = 705 + plungerCharge * 17;
    c.drawLine(
      const Offset(352, 674),
      Offset(352, handleY),
      Paint()
        ..color = const Color(0xFFB7C1C9)
        ..strokeWidth = 2.5,
    );
    for (var i = 0; i < 6; i++) {
      final y = 693.0 + i * (2.1 + plungerCharge * 1.4);
      c.drawLine(
        Offset(347, y),
        Offset(357, y + 2),
        Paint()
          ..color = metal.withValues(alpha: 0.76)
          ..strokeWidth = 1.5,
      );
    }
    c.drawCircle(
      Offset(352, handleY),
      9,
      Paint()..color = const Color(0xFF172029),
    );
    c.drawCircle(
      Offset(351, handleY - 1),
      6,
      Paint()
        ..shader = const RadialGradient(
          colors: [Color(0xFFFCF8E9), Color(0xFF8494A1), Color(0xFF23303C)],
        ).createShader(
          Rect.fromCircle(center: Offset(351, handleY - 1), radius: 6),
        ),
    );
  }

  /// Hazards are drawn at their precise active collision coordinates. The
  /// printed artwork never substitutes for a functional machine component.
  void _drawSpecialHardware(Canvas c) {
    switch (table.universe) {
      case PinballUniverseId.celestial:
        if (table.variant == 0) {
          _drawPortalAssembly(c, const Offset(111, 404));
          _drawPortalAssembly(c, const Offset(289, 156));
        } else if (table.variant == 1) {
          _drawGravityAssembly(c, const Offset(114, 359), 25);
          _drawGravityAssembly(c, const Offset(285, 187), 18);
        } else {
          final x = 200.0 + 52 * math.sin(_time * 1.6);
          _drawMovingGate(c, Offset(x - 34, 438), Offset(x + 34, 438));
        }
      case PinballUniverseId.neon:
        if (table.variant == 0) {
          _drawBoostStrip(c, const Offset(200, 391));
        } else if (table.variant == 1) {
          _drawPortalAssembly(c, const Offset(100, 392));
          _drawPortalAssembly(c, const Offset(280, 147));
        } else {
          _drawGravityAssembly(c, const Offset(200, 297), 28);
          final x = 200.0 + 46 * math.sin(_time * 1.9);
          _drawMovingGate(c, Offset(x - 22, 474), Offset(x + 22, 474));
        }
      case PinballUniverseId.clockwork:
        if (table.variant == 0) {
          _drawGearAssembly(c, Offset(200 + 36 * math.sin(_time * 1.5), 433));
        } else if (table.variant == 1) {
          if (_time % 4.8 < 2.8) {
            _drawMovingGate(c, const Offset(127, 457), const Offset(273, 457));
          } else {
            for (final x in [127.0, 273.0]) {
              c.drawCircle(
                Offset(x, 457),
                8,
                Paint()..color = const Color(0xFFA7A6A1),
              );
            }
          }
        } else {
          final shift = 38 * math.sin(_time * 1.22);
          _drawMovingGate(c, Offset(86 + shift, 375), Offset(170 + shift, 375));
          _drawGearAssembly(c, Offset(255 - shift * 0.6, 471));
        }
    }
  }

  void _drawPortalAssembly(Canvas c, Offset center) {
    c.drawCircle(
      center + const Offset(2, 3),
      25,
      Paint()..color = Colors.black.withValues(alpha: 0.76),
    );
    c.drawCircle(
      center,
      22,
      Paint()
        ..shader = RadialGradient(
          colors: [
            table.accent.withValues(alpha: 0.55),
            const Color(0xFF050912),
            const Color(0xFF151C25),
          ],
        ).createShader(Rect.fromCircle(center: center, radius: 22)),
    );
    c.drawCircle(
      center,
      22,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = const Color(0xFFADB7C0),
    );
    for (var i = 0; i < 6; i++) {
      final angle = i * math.pi / 3 + _time * 0.5;
      final p = center + Offset(math.cos(angle), math.sin(angle)) * 18;
      c.drawCircle(p, 2.4, Paint()..color = table.accent);
    }
  }

  void _drawGravityAssembly(Canvas c, Offset center, double radius) {
    c.drawCircle(
      center + const Offset(2, 3),
      radius + 3,
      Paint()..color = Colors.black.withValues(alpha: 0.55),
    );
    c.drawCircle(
      center,
      radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4
        ..color = const Color(0xFF9FAFBC),
    );
    c.drawCircle(
      center,
      radius * 0.7,
      Paint()
        ..shader = RadialGradient(
          colors: [table.secondary.withValues(alpha: 0.6), Colors.black],
        ).createShader(Rect.fromCircle(center: center, radius: radius)),
    );
    for (var i = 0; i < 8; i++) {
      final angle = i * math.pi / 4 + _time * 0.22;
      final p = center + Offset(math.cos(angle), math.sin(angle)) * radius;
      c.drawCircle(p, 2.2, Paint()..color = const Color(0xFFD9E1E5));
    }
  }

  void _drawMovingGate(Canvas c, Offset a, Offset b) {
    // Distinct gunmetal motor housings and an actual moving crossbar.
    for (final post in [a, b]) {
      c.drawCircle(
        post + const Offset(2, 3),
        8,
        Paint()..color = Colors.black.withValues(alpha: 0.65),
      );
      c.drawCircle(post, 5.5, Paint()..color = const Color(0xFF8799A5));
      c.drawCircle(post, 2, Paint()..color = table.accent);
    }
    _drawMetalRail(c, a, b);
  }

  void _drawGearAssembly(Canvas c, Offset center) {
    final sprite = _hazardSprite;
    if (sprite != null) {
      _drawRotatingSprite(c, sprite, center, 23, _time * 1.4);
    } else {
      c.drawCircle(center, 21, Paint()..color = const Color(0xFF7B817A));
      c.drawCircle(center, 14, Paint()..color = const Color(0xFF1D252B));
      for (var i = 0; i < 12; i++) {
        final a = i * math.pi / 6 + _time * 1.4;
        final p = center + Offset(math.cos(a), math.sin(a)) * 21;
        c.drawCircle(p, 4, Paint()..color = const Color(0xFFC2C3B6));
      }
    }
    c.drawCircle(center, 5, Paint()..color = const Color(0xFF151A20));
    c.drawCircle(center, 2.5, Paint()..color = const Color(0xFFE3E0D6));
  }

  void _drawBoostStrip(Canvas c, Offset center) {
    final rect = RRect.fromRectAndRadius(
      Rect.fromCenter(center: center, width: 108, height: 16),
      const Radius.circular(4),
    );
    c.drawRRect(rect, Paint()..color = const Color(0xFF121D27));
    c.drawRRect(
      rect,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = const Color(0xFF8799A5),
    );
    for (var i = -2; i <= 2; i++) {
      final x = center.dx + i * 19;
      final arrow =
          Path()
            ..moveTo(x - 5, center.dy + 3)
            ..lineTo(x, center.dy - 4)
            ..lineTo(x + 5, center.dy + 3);
      c.drawPath(
        arrow,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = table.accent,
      );
    }
  }

  void _drawMetalRail(Canvas c, Offset a, Offset b) {
    c.drawLine(
      a + const Offset(2, 3),
      b + const Offset(2, 3),
      Paint()
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 6
        ..color = Colors.black.withValues(alpha: 0.72),
    );
    c.drawLine(
      a,
      b,
      Paint()
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 4
        ..color = const Color(0xFF5D6B75),
    );
    c.drawLine(
      a - const Offset(0.7, 0.7),
      b - const Offset(0.7, 0.7),
      Paint()
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 1.8
        ..color = const Color(0xFFE0E5E3).withValues(alpha: 0.92),
    );
  }

  void _drawRing(
    Canvas c,
    Offset center,
    double radius,
    Color color,
    double width,
  ) {
    c.drawCircle(
      center,
      radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = width * 3
        ..color = color.withValues(alpha: 0.08),
    );
    c.drawCircle(
      center,
      radius,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = width
        ..color = color.withValues(alpha: 0.77),
    );
  }

  void _glowCircle(Canvas c, Offset center, double radius, Color color) {
    c.drawCircle(
      center,
      radius + 9,
      Paint()
        ..shader = RadialGradient(
          colors: <Color>[color.withValues(alpha: 0.45), Colors.transparent],
        ).createShader(Rect.fromCircle(center: center, radius: radius + 11)),
    );
    c.drawCircle(
      center,
      radius,
      Paint()
        ..color = color.withValues(alpha: 0.8)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4,
    );
    c.drawCircle(
      center,
      radius - 5,
      Paint()..color = Colors.white.withValues(alpha: 0.22),
    );
  }

  void _glowLine(Canvas c, Offset a, Offset b, Color color, double width) {
    c.drawLine(
      a,
      b,
      Paint()
        ..strokeCap = StrokeCap.round
        ..strokeWidth = width * 4
        ..color = color.withValues(alpha: 0.10),
    );
    c.drawLine(
      a,
      b,
      Paint()
        ..strokeCap = StrokeCap.round
        ..strokeWidth = width
        ..color = color.withValues(alpha: 0.88),
    );
  }

  void _drawFlipper(Canvas c, Offset pivot, bool left, double lift) {
    final angle = left ? -0.19 - lift * 0.67 : math.pi + 0.19 + lift * 0.67;
    final direction = Offset(math.cos(angle), math.sin(angle));
    final normal = Offset(-direction.dy, direction.dx);
    final tip = pivot + direction * 78;
    final flipper =
        Path()
          ..moveTo((pivot - normal * 10).dx, (pivot - normal * 10).dy)
          ..lineTo((tip - normal * 6).dx, (tip - normal * 6).dy)
          ..arcToPoint(tip + normal * 6, radius: const Radius.circular(7))
          ..lineTo((pivot + normal * 10).dx, (pivot + normal * 10).dy)
          ..close();
    c.drawPath(
      flipper.shift(const Offset(3, 4)),
      Paint()..color = Colors.black.withValues(alpha: 0.72),
    );
    final sprite = _flipperSprite;
    if (sprite != null) {
      // The source is orthographic with its pivot at roughly 15% of the
      // image width; the shader-less 2D sprite rotates at the real joint.
      c.save();
      c.translate(pivot.dx, pivot.dy);
      c.rotate(angle);
      c.drawImageRect(
        sprite,
        Rect.fromLTWH(0, 0, sprite.width.toDouble(), sprite.height.toDouble()),
        const Rect.fromLTWH(-15, -15.5, 93, 31),
        Paint()..filterQuality = FilterQuality.high,
      );
      c.restore();
      return;
    }
    c.drawPath(flipper, Paint()..color = const Color(0xFF181F28));
    c.drawPath(
      flipper,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 4.5
        ..strokeJoin = StrokeJoin.round
        ..color =
            table.universe == PinballUniverseId.clockwork
                ? const Color(0xFFCBB28C)
                : const Color(0xFF9FB0BF),
    );
    c.drawLine(
      pivot + direction * 12 - normal * 1.5,
      tip - direction * 10 - normal * 1.5,
      Paint()
        ..strokeCap = StrokeCap.round
        ..strokeWidth = 2
        ..color = const Color(0xFFF6F5E8).withValues(alpha: 0.82),
    );
    c.drawCircle(pivot, 9, Paint()..color = const Color(0xFF101923));
    c.drawCircle(pivot, 5, Paint()..color = const Color(0xFFB5C2CC));
  }
}
