# PINBALL UNIVERSES — Premium gameplay research and V3 implementation

This is a deliberately honest studio-grade quality register for the nine
portrait, 2D-only pinball machines. It separates implemented behavior from
the work still required for a finished commercial-quality game.

## 1. Research basis: the substance of real pinball

The old prototype gave the player three bumpers, a few lines, canned flipper
bounces and one global hit counter. More illustrated detail cannot rescue that
structure. Reference features confirmed in primary sources:

- **Real shooter choices and skill shots:** Stern's official *Godzilla*
  rulesheet explicitly distinguishes multiple plunge strengths/routes and
  awards different ball-save durations. A plunger must fire into the shooter
  feed, not immediately across its divider.
- **Actual mechanical systems:** *Godzilla* documents rotating target banks,
  spinner/jump ramps, magnets, ball locks, timed shots, a collapsing bridge
  and multiball rules. These are gameplay mechanics with distinct sensors,
  not decorative background drawings.
- **Goals and strategy:** Official rulesheets explain qualifying jackpots,
  making lit shots, repeating ramps and progressing through modes. A random
  number-of-hits counter is not an adequate scoring director.
- **Physics:** Flame recommends the Forge2D bridge for fully physical
  bodies/fixtures/joints and contact callbacks. The current custom solver can
  be improved, but cannot yet claim the robustness of a full rigid-body engine.
- **Live switch layouts:** Stern's official *Rush* and *Jurassic Park*
  service manuals separately document sling switches, outlane rollovers and
  other distinct playfield sensors. These are independent mechanism inputs,
  which is why V3's target and rollover events are separate from bumper hits.
- **Mobile controls/audio:** Flutter's pointer `Listener` supports low-level
  down/up events for simultaneous left and right flippers. Chrome's Web Audio
  policy can suspend playback until the first genuine user gesture; sound
  initialization must respect that interaction boundary.

### References (primary sources)

1. Stern Pinball: *Godzilla* official rulesheet,
   https://sternpinball.com/wp-content/uploads/2022/06/Godzilla-Rulesheet.pdf
2. Stern Pinball: *Godzilla* official machine features,
   https://sternpinball.com/game/godzilla/
3. Stern Pinball: official manuals directory,
   https://sternpinball.com/manuals/
4. Flame: Forge2D overview and contact callbacks,
   https://docs.flame-engine.org/latest/bridge_packages/flame_forge2d/forge2d.html
5. Flame: physics collisions vs generic hitboxes,
   https://docs.flame-engine.org/latest/flame/collision_detection.html
6. Stern: *Rush* operation manual, switch/driver reference,
   https://sternpinball.com/wp-content/uploads/2022/05/Rush_Pro_web.pdf
7. Flutter: pointer input `Listener`,
   https://api.flutter.dev/flutter/widgets/Listener-class.html
8. Chrome: Web Audio autoplay policy in games,
   https://developer.chrome.com/blog/web-audio-autoplay

No copyrighted machine artwork, audio recordings, or rule text has been
reproduced. These are functional design principles applied to original tables.

## 2. Actual V3 changes implemented

### Contact and ball response

- Pure-Dart physics module `physics_contact.dart` implements capsule contacts,
  collision normals, penetration correction, restitution, moving-surface
  velocity, tangential Coulomb friction and a mass-normalized ball spin term.
- Both flippers rotate with their real joint angular velocity. Contact-point
  distance from the pivot now matters because the tip moves faster.
- Removed the old canned `velocity = Offset(...)` flipper impulse.
- Raised the fixed contact simulation step to 240 Hz, reducing maximum
  per-step ball travel at the 1,600 px/s cap to 6.67 pixels.
- Powered contacts cannot silently accelerate balls that are separating.

### Playfield hardware and controls

- Original transparent **top-down 2D** cutout assets for a manufactured
  rubberized flipper bat and steel/plastic pop bumper. These replace the
  simplistic line flippers and ornate, jewel-like bumper illustrations.
- Artwork is rotated and scaled from the actual programmed pivot and radius.
- The existing pull-down/release plunger and isolated shooter lane remain.
- Precise playing surfaces, moving gates, targets, rollovers and routes from
  V2 remain part of the scene; no "fake" baked-in collision objects.

### Gameplay rules and objectives

- Independent, pure-Dart per-machine rules, **nine unique profiles**.
- Distinct orbit, ramp, targets and lane-bank event tracking.
- Alternating shot combos only score a combo within each machine's time limit.
- Table modes advance through actual shot and target objectives.
- Multiball is now qualified through ramps and a cleared target bank,
  not arbitrarily after 12 bumper hits.
- Unique feature/jackpot names and tuning for every machine.
- Rollover lane completion refreshes a short ball save.
- The compact game HUD exposes the next objective.

## 3. Deterministic checks passed in our independent Dart environment

| Gate | Result |
|---|---|
| Six plunger power settings × two fixed timesteps | 12/12 passed |
| Contact normal, penetration, active flipper, friction, spin, no ghost kick | 12/12 passed |
| Nine distinct rule tables, mode progression, jackpots, multiball, reset | 9/9 passed |
| Pure-Dart engine analysis | No issues |
| Asset transparency, packaging checks | Valid PNG / ZIP |

**Important:** A complete Flutter build, original test suite, interactive
touch response and on-device performance test have **not** yet been completed
in this isolated environment because third-party Flutter packages are not
downloadable here. The V3 installer runs those checks in the already-working
Codespace and restores the working version automatically if they fail.

## 4. Still required to reach a genuinely high-end finished game

This update is a strong mechanical prototype milestone, not final production.

**Phase A — Physics fidelity and reliability**

- Migrate to Forge2D rigid bodies, revolute motor joints and contact filters.
- Real continuous collision detection, slopes, ramp height layers, flipper
  EOS stops, input buffering and live ball-spin friction.
- Calibrate mechanical powers from repeatable launch and flipper shot tests;
  measure shot-arc success, dead-ball frequency and early drain rates.
- Mobile touch-latency and frame-time instrumentation across lower-end phones.

**Phase B — Nine authentic machines**

- Give each of the nine a distinct physical layout *and* unique individually
  composed cabinet/playfield illustration, rather than only unique geometry
  over one underlay per universe.
- Functional scoops, ball locks, diverters, spinners, stand-ups, multiple
  ramp levels, magnets and tilt/nudge under the rules engine.
- Sequential missions, lamp choreography, timed hurry-ups and true jackpot
  multipliers with objective feedback.

**Phase C — Premium audiovisual finishing**

- Physical insert lamps with shadows and reflections, measured contrast,
  cabinet/glass composition, quality typography and legible rule callouts.
- Ball material sound layers by surface, plunger pull/release, flipper motor
  coils, realistic target impacts, restrained music beds, dynamic mix/ducking.
- Accessibility (mute, motion reduction, color-readable lamp states),
  haptics, pause/resume, platform-adaptive loading and save recovery.

**Release gate:** Flutter analyze + all tests + browser build + visual
before/after QA + full phone gameplay pass. Never overwrite the previous live
game when this gate fails.
