import '../lib/game/machine_rules.dart';

void expect(bool success, String why) {
  if (!success) throw StateError('RULES_TEST_FAILED: $why');
}

void main() {
  expect(machineProfiles.length == 9, 'nine separate rule profiles');
  final signatures =
      machineProfiles.values
          .map(
            (p) =>
                '${p.orbitGoal}:${p.rampGoal}:${p.comboWindow}:${p.jackpot}:${p.featureName}',
          )
          .toSet();
  expect(signatures.length == 9, 'no generic duplicate machines');

  for (final entry in machineProfiles.entries) {
    final rules = MachineRules(entry.key);
    rules.record(MachineEvent.orbit, 0);
    final firstRamp = rules.record(MachineEvent.ramp, 1);
    expect(firstRamp.bonus >= 2000, '${entry.key}: combo rewards alternation');
    expect(rules.modeIndex == 1, '${entry.key}: mode 1 after two shots');
    rules.record(MachineEvent.targetBank, 2);
    final lanes = rules.record(MachineEvent.rolloverBank, 3);
    expect(
      rules.modeIndex == 2,
      '${entry.key}: target and rollover banks unlock mission',
    );
    expect(
      lanes.ballSaveSeconds >= 5,
      '${entry.key}: completed lane bank saves ball',
    );
    var multiballStarts = 0;
    for (
      var i = 1;
      i < entry.value.rampGoal + entry.value.multiballRamps + 4;
      i++
    ) {
      final award = rules.record(MachineEvent.ramp, i * 3.0 + 10);
      if (award.startMultiball) multiballStarts++;
    }
    for (var i = 1; i < entry.value.orbitGoal + 2; i++) {
      rules.record(MachineEvent.orbit, 100 + i.toDouble());
    }
    expect(
      rules.modeIndex == 3,
      '${entry.key}: completion lights table-specific feature',
    );
    final jackpot = rules.record(MachineEvent.ramp, 150);
    expect(
      jackpot.bonus >= entry.value.jackpot,
      '${entry.key}: jackpot after feature lit',
    );
    expect(
      multiballStarts == 1,
      '${entry.key}: objective-based multiball once',
    );
    rules.reset();
    expect(
      rules.modeIndex == 0 && !rules.multiballTriggered,
      '${entry.key}: full restart reset',
    );
    print('MACHINE_RULES_PASS: ${entry.key}');
  }
  print('MACHINE_RULES_9_OF_9_PASS');
}
