import 'dart:math' as math;

import '../lib/game/physics_contact.dart';

void check(bool condition, String label) {
  if (!condition) throw StateError('CONTACT_TEST_FAILED: $label');
  print('CONTACT_PASS: $label');
}

void main() {
  final wall = ContactPhysics.capsule(
    ball: const ContactBall(x: 106, y: 250, vx: -420, vy: 0),
    ax: 100,
    ay: 100,
    bx: 100,
    by: 400,
    radius: 8,
    restitution: 0.82,
  );
  check(wall.collided && wall.ball.vx > 0, 'wall rebounds inward');
  check(wall.ball.x >= 108, 'wall resolves penetration');
  check(wall.ball.vx.isFinite && wall.ball.spin.isFinite, 'wall finite');

  final missed = ContactPhysics.capsule(
    ball: const ContactBall(x: 150, y: 250, vx: -420, vy: 0),
    ax: 100,
    ay: 100,
    bx: 100,
    by: 400,
    radius: 8,
    restitution: 0.82,
  );
  check(!missed.collided, 'distant wall misses');

  const testBall = ContactBall(x: 162, y: 477, vx: 0, vy: 280);
  ContactResult flipper(double angular) => ContactPhysics.capsule(
    ball: testBall,
    ax: 120,
    ay: 500,
    bx: 195,
    by: 480,
    radius: 18,
    restitution: 0.55,
    friction: 0.32,
    angularSpeed: angular,
    pivotX: 120,
    pivotY: 500,
  );
  final stationary = flipper(0);
  final active = flipper(-10);
  check(stationary.collided && active.collided, 'flipper hits actual ball');
  check(
    active.ball.vy < stationary.ball.vy - 250,
    'powered flipper transfers angular momentum',
  );
  check(active.ball.vy < 0, 'powered flipper shoots upward');
  check(
    active.contactFraction > 0.2 && active.contactFraction < 0.9,
    'flipper contact location',
  );

  final away = ContactPhysics.capsule(
    ball: const ContactBall(x: 162, y: 477, vx: 0, vy: -420),
    ax: 120,
    ay: 500,
    bx: 195,
    by: 480,
    radius: 18,
    restitution: 0.6,
  );
  check(away.normalImpulse == 0, 'separating contact has no ghost kick');

  var b = ContactBall(x: 162, y: 477, vx: 400, vy: 250, spin: 0);
  final spin = ContactPhysics.capsule(
    ball: b,
    ax: 120,
    ay: 500,
    bx: 195,
    by: 480,
    radius: 18,
    restitution: 0.6,
    friction: 0.35,
  );
  check(spin.ball.spin.abs() > 0.01, 'tangent impact creates rolling spin');
  check(
    [
      spin.ball.vx,
      spin.ball.vy,
      spin.ball.spin,
    ].every((n) => n.isFinite && n.abs() < 5000),
    'collision energy bounded',
  );
  check(
    math
        .sqrt(spin.ball.vx * spin.ball.vx + spin.ball.vy * spin.ball.vy)
        .isFinite,
    'no numerical instability',
  );
  print('CONTACT_PHYSICS_12_OF_12_PASS');
}
