import '../lib/game/shooter_guide.dart';

void main() {
  for (final power in <double>[0.0, 0.2, 0.52, 0.65, 0.77, 1.0]) {
    for (final hz in <int>[120, 240]) {
      var ball = ShooterGuideState(
        x: ShooterGuide.laneX,
        y: 665,
        vx: 0,
        vy: ShooterGuide.velocityForPull(power),
        arcTime: -1,
      );
      var inLane = true;
      var entered = false;
      for (var frame = 0; frame < hz * 3; frame++) {
        ball = ShooterGuide.advance(ball, 1 / hz, power: power);
        if (inLane) {
          assert(ball.x == ShooterGuide.laneX);
          assert(ball.x > ShooterGuide.dividerX);
        }
        if (ball.arcTime >= 0) inLane = false;
        if (ball.enteredPlayfield) {
          entered = true;
          assert(ball.x == 305);
          assert(ball.y == 163);
          assert(ball.x < ShooterGuide.dividerX);
          assert(ball.vx < 0);
          assert(ball.vy > 0);
          break;
        }
      }
      if (!entered)
        throw StateError('Plunger power $power never reaches play.');
      print(
        'SHOOTER_POWER_${(power * 100).round()}_${hz}HZ: ENTERED_PLAYFIELD',
      );
    }
  }
  print('SHOOTER_GUIDE_12_OF_12_PASS');
}
