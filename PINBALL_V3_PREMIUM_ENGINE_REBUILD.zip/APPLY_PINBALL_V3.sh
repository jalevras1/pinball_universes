#!/usr/bin/env bash
set -Eeuo pipefail

# Pinball Universes V3 premium-physics update. Run from ZIP in Codespaces.
# It never installs a Flutter SDK, deletes the old game, or rewrites history.
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR='/workspaces/pinball_universes'
EXPECTED_BASE='3c94da33acf056b5b6164a46797859a87e5fdb14'
VERSION='premium-physics-v3-20261122'
FILES=(
  'pubspec.yaml'
  'lib/main.dart'
  'lib/game/pinball_game.dart'
  'lib/game/playfield_plan.dart'
  'lib/game/shooter_guide.dart'
  'lib/game/physics_contact.dart'
  'lib/game/machine_rules.dart'
  'test/playfield_plan_test.dart'
  'test/premium_physics_test.dart'
  'tools/verify_shooter_guide.dart'
  'tools/verify_contact_physics.dart'
  'tools/verify_machine_rules.dart'
)
BACKUP_FILES=(
  "${FILES[@]}"
  'pubspec.lock'
  'assets/playfields_v2/celestial.png'
  'assets/playfields_v2/neon.png'
  'assets/playfields_v2/clockwork.png'
  'assets/gameplay_v3/flipper_pro.png'
  'assets/gameplay_v3/bumper_pro.png'
)

abort() { printf 'PINBALL_V3_STOP: %s\n' "$*" >&2; exit 2; }

[[ -d "$PROJECT_DIR/.git" ]] || abort 'Pinball Codespace not found at /workspaces/pinball_universes.'
for path in "${FILES[@]}" assets/playfields_v2/celestial.png assets/playfields_v2/neon.png assets/playfields_v2/clockwork.png assets/gameplay_v3/flipper_pro.png assets/gameplay_v3/bumper_pro.png; do
  [[ -s "$SOURCE_DIR/$path" ]] || abort "Incomplete update package: $path is missing. No game files changed."
done

cd "$PROJECT_DIR"
[[ "$(git branch --show-current)" == 'chatgpt-pinball-development' ]] || abort 'Switch to the existing chatgpt-pinball-development branch first.'
git merge-base --is-ancestor "$EXPECTED_BASE" HEAD || abort 'Unexpected source version: no changes were made. Preserve your branch and request a refreshed update.'
git diff --quiet || abort 'You have local source edits. Commit or save them first; nothing was overwritten.'
git diff --cached --quiet || abort 'You have staged source edits. Commit or save them first; nothing was overwritten.'
# `git diff` cannot see untracked work. Never overwrite a user's new source
# or artwork that happens to have the same filename as a V3 addition.
for path in "${BACKUP_FILES[@]}"; do
  if [[ -e "$path" ]] && ! git ls-files --error-unmatch -- "$path" > /dev/null 2>&1; then
    abort "Existing untracked file would be replaced: $path. No game files changed."
  fi
done

SDK="$HOME/pinball_flutter_prebuilt_3501/flutter/bin/flutter"
[[ -x "$SDK" ]] || abort 'The previously working prebuilt Flutter 3.50.1 SDK is not present. No installation was attempted.'

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="$PROJECT_DIR/.pinball_v3_backups/$STAMP"
mkdir -p "$BACKUP_DIR"
for path in "${BACKUP_FILES[@]}"; do
  if [[ -f "$path" ]]; then
    mkdir -p "$BACKUP_DIR/$(dirname "$path")"
    cp -p "$path" "$BACKUP_DIR/$path"
  fi
done
if [[ -d build/web ]]; then
  mkdir -p "$BACKUP_DIR/build"
  cp -a build/web "$BACKUP_DIR/build/web"
fi
printf 'PINBALL_V3_BACKUP: %s\n' "$BACKUP_DIR"

restore_previous_game() {
  local error_code="$?"
  trap - ERR
  set +e
  printf 'PINBALL_V3_ROLLBACK: Build or validation failed (%s). Restoring existing game...\n' "$error_code"
  for path in "${BACKUP_FILES[@]}"; do
    if [[ -f "$BACKUP_DIR/$path" ]]; then
      cp -p "$BACKUP_DIR/$path" "$PROJECT_DIR/$path"
    elif [[ -f "$SOURCE_DIR/$path" ]]; then
      # A newly introduced file has no original; move it into the backup.
      mkdir -p "$BACKUP_DIR/introduced/$(dirname "$path")"
      mv "$PROJECT_DIR/$path" "$BACKUP_DIR/introduced/$path"
    fi
  done
  # Move, never destroy, an incomplete generated preview out of the way.
  # Restoring with a directory copy alone could leave broken new JS bundles.
  if [[ -d "$PROJECT_DIR/build/web" ]]; then
    mkdir -p "$BACKUP_DIR"
    mv "$PROJECT_DIR/build/web" "$BACKUP_DIR/failed_web"
  fi
  if [[ -d "$BACKUP_DIR/build/web" ]]; then
    mkdir -p "$PROJECT_DIR/build"
    cp -a "$BACKUP_DIR/build/web" "$PROJECT_DIR/build/web"
  fi
  git restore --staged -- "${FILES[@]}" 2>/dev/null || true
  printf 'PINBALL_V3_ROLLBACK_COMPLETE: Old game and preview restored. Backup: %s\n' "$BACKUP_DIR"
  exit "$error_code"
}
trap restore_previous_game ERR

for path in "${FILES[@]}"; do
  mkdir -p "$(dirname "$path")"
  cp -p "$SOURCE_DIR/$path" "$path"
done
mkdir -p assets/playfields_v2
cp -p "$SOURCE_DIR/assets/playfields_v2/"*.png assets/playfields_v2/
mkdir -p assets/gameplay_v3
cp -p "$SOURCE_DIR/assets/gameplay_v3/"*.png assets/gameplay_v3/

export FLUTTER_SUPPRESS_ANALYTICS=true
export DART_VM_OPTIONS='--old_gen_heap_size=2048'
export NO_PROXY="${NO_PROXY:+$NO_PROXY,}localhost,127.0.0.1,::1"
export no_proxy="$NO_PROXY"

echo 'PINBALL_V3_CHECK_1: Running deterministic physics and rules tests...'
"$(dirname "$SDK")/dart" --enable-asserts tools/verify_shooter_guide.dart
"$(dirname "$SDK")/dart" --enable-asserts tools/verify_contact_physics.dart
"$(dirname "$SDK")/dart" --enable-asserts tools/verify_machine_rules.dart
echo 'PINBALL_V3_CHECK_2: Resolving Flutter packages...'
timeout 300 "$SDK" pub get
echo 'PINBALL_V3_CHECK_3: Checking Dart and Flutter source...'
timeout 180 "$SDK" analyze --no-fatal-infos --no-fatal-warnings
echo 'PINBALL_V3_CHECK_4: Running original and V3 tests...'
timeout 240 "$SDK" test --reporter expanded
echo 'PINBALL_V3_CHECK_5: Building the web game...'
timeout 420 "$SDK" build web --release --no-wasm-dry-run --no-pub
[[ -s build/web/index.html ]] || { echo 'Web build output missing.'; false; }

trap - ERR
git add -- "${FILES[@]}" pubspec.lock assets/playfields_v2 assets/gameplay_v3
if ! git diff --cached --quiet; then
  git commit -m "${VERSION}: motorized flipper physics, table missions, premium hardware"
  if GIT_TERMINAL_PROMPT=0 git push -u origin chatgpt-pinball-development; then
    echo 'PINBALL_V3_GITHUB_SAVED'
  else
    echo 'PINBALL_V3_GITHUB_PUSH_PENDING: Working build is saved in a local commit.'
  fi
fi

if ! curl --noproxy '*' -fsS --max-time 3 -o /dev/null http://127.0.0.1:8766/; then
  nohup python3 -m http.server 8766 --bind 0.0.0.0 --directory build/web \
    > .pinball_v3_preview.log 2>&1 < /dev/null &
fi
echo 'PINBALL_V3_SUCCESS: Refresh Codespaces port 8766. Test plunger, flippers, combo shots, target banks and ball saves.'
