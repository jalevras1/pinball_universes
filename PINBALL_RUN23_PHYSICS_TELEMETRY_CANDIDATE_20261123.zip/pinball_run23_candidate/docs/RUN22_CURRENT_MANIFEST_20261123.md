# Pinball Universes — Current engineering/art milestone (Run 22)

Owner: `jalevras1`. Repository: `jalevras1/pinball_universes`. This is **not** DRAGON LUNARYVELL.

## Source of truth

| Stage | Branch/record | Real status |
| --- | --- | --- |
| Existing development game | `chatgpt-pinball-development` @ `0dc54ea1` | Preserved; unchanged this run |
| Run18/19 shooter prototype | `feature/pinball-run19-exact-shooter-exit-20261123` @ `7b08cf5` | Remote feature stage only; not merged |
| Run20 trajectory tests | `libfile_41a148ede1e48191842f199c12268491` | Saved tests, not executed with Flutter |
| Run21 remainder-aware shooter | Local commit `431de21` | Saved candidate, not installed |
| **Run22 developer console** | Local feature branch `feature/pinball-run22-developer-console-20261123`, source commit `dfb1dc840f8e484dce0c4931d33c16b4c0026273` | DEV button, overlay, scenarios and tests staged locally; not installed or compiled |
| Earlier illustrated flagship branch | `feature/pinball-illustrated-machines-20261123` @ `875cbe3` | Separate staged art integration; no merge into Run22 |
| Nine machine artwork candidates | `libfile_0e97beca10cc8191bbd6688d2a385fce` | Distinct art preserved; not nine tested runtime integrations |

### Canonical premium art packages

- Astral Orrery / Circuit Velocity / Grand Mechanism: `libfile_71a9aa4c4dbc8191ab8c6f7c0b8863d5`.
- Moonfall Sanctuary / Quantum Grid / Chrono Citadel: `libfile_d1b4134c76b0819191cdfd9ad202fc26`.
- Nebula Tempest / Reactor Rush / Brass Labyrinth: `libfile_42fd84dc1f208191aefab3b0061d422f`.
- Research Bible: `libfile_4d8e2b38c5988191b0bd897b297b68c4`.

## Locked production decisions

- Entirely original premium 2D illustrated physical machines; visible hardware must match functional hitboxes, ramps, drains and targets.
- Exactly nine named distinct boards, three each Celestial/Neon/Clockwork.
- Launcher never steers horizontally; downward drag changes power only; weak shots rearm.
- Developer button on real gameplay HUD with repeatable tests and on-phone collider overlay; developer scoring must not enter personal bests.
- Preserve every existing live branch, rollback checkpoint and user edit; no untested merge or publish.
- All four gates remain mandatory: actual in-engine visual/collider fidelity, navigation/physics, premium-art integrity/phone legibility, verified Flutter analyzer/tests/web build/browser QA/Android owner acceptance.

## Immediate follow-up

Verified packaged source: `PINBALL_RUN22_DEVELOPER_CONSOLE_CANDIDATE_20261123.zip` (18 versioned source/test/doc paths, binary patch and checkpoint note); SHA-256 `bd384552bc76e02f4ccf51739de9fff412733c91a862b8741af6d1f0b3b8b586`. `unzip -t` passed; this does not validate Flutter functionality.

1. Run existing Flutter SDK against Run22 isolated worktree: formatter, analyzer, full tests, web build. Diagnose any failures, **especially** nine-board bumper/flipper and developer UI tests.
2. Open a separate phone-size browser preview and exercise DEV controls repeatedly without app relaunch; compare hitbox overlay with painted geometry and verify score exclusion from personal bests.
3. Investigate earliest-contact ordering across multiple rails and flipper sweep mechanics. Current custom solver remains an unverified prototype.
4. Integrate premium nine-machine art only after precise geometry and independent QA gates pass; do not generate redundant table art.
