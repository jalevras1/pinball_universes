# Pinball Universes — Current milestone index (Run 21 candidate)

This record supersedes earlier Run18/19/20 handoff summaries **for status tracking only**. It does not supersede installed source or erase previous assets.

## Live vs staged

| Milestone | Reference | Verified status |
| --- | --- | --- |
| Development source | `chatgpt-pinball-development` @ `0dc54ea1` | Unchanged, current baseline |
| Run18 mechanics candidate | `feature/pinball-run18-mechanics-validation-20261123` @ `3a74c74c` | Remotely staged only |
| Run19 exact shooter exit | `feature/pinball-run19-exact-shooter-exit-20261123` @ `7b08cf5b` | Remotely staged, foundation of Run21 |
| Run20 regression package | `libfile_41a148ede1e48191842f199c12268491` | Four additional tests, not deployed |
| **Run21 shooter handoff** | Local commit `431de21df42f2386c77c9ebe7a0223f6ea1bb0f1` from `7b08cf5b` | Staged in isolated local branch; not pushed/compiled |
| Illustrated flagship machines | `feature/pinball-illustrated-machines-20261123` @ `875cbe3` | Earlier separate preview QA claimed, not merged into Run19/21 |
| Nine premium original artworks | `PINBALL_NINE_MACHINE_ART_MANIFEST_20261123.md` (`libfile_0e97beca10cc8191bbd6688d2a385fce`) | Asset candidates saved, not nine validated playable integrations |

### Canonical visual packages

- Flagship Astral Orrery / Circuit Velocity / Grand Mechanism: `libfile_71a9aa4c4dbc8191ab8c6f7c0b8863d5`.
- Moonfall Sanctuary / Quantum Grid / Chrono Citadel: `libfile_d1b4134c76b0819191cdfd9ad202fc26`.
- Nebula Tempest / Reactor Rush / Brass Labyrinth: `libfile_42fd84dc1f208191aefab3b0061d422f`.
- Reference research Bible: `libfile_4d8e2b38c5988191b0bd897b297b68c4`.

### Current durable Run21 handoff

- Source bundle `PINBALL_RUN21_SHOOTER_HANDOFF_CANDIDATE_20261123.zip`, Library `libfile_ee83407f34388191959f70e65dabf0a3`, SHA256 `33f82c253096edaf03bb44f1cb97b48c18b8003ef9042c9a7b7422fcd2eb16ba`.
- Candid QA report `RUN21_QA_20261123.md`, Library `libfile_dfff264de2c08191be95b8f6187a15c4`.
- This current milestone manifest, Library `libfile_b7ddeaab6c3c81919cecba9a3c781816`.
- The local source was committed at the staging SHA above. The bundle contains that same source and earlier pre-commit manifest text; this standalone manifest updates the resulting source SHA and Library IDs and is deliberately maintained separately.

## Next priorities

1. Run formatter, analyzer, entire Flutter test suite and release web build on Run21 isolated candidate; correct any actual failures.
2. Compare multi-collider continuous-contact ordering, weak launch re-entry and flipper impulse against real game behavior, including all nine board variants.
3. Only then align premium assembled-machine art to collision geometry and capture actual runtime phone-sized screenshots; owner Android multitouch/fps still required.
4. Continue never to merge or publish before the four acceptance gates pass. Preserve both live branch and all earlier staged work.
