# Run21 shooter-tube handoff — staged engineering candidate

This is a **NOT INSTALLED / NOT PLAYTESTED** delta for `jalevras1/pinball_universes`. It was built from the exact Run19 feature-branch commit `7b08cf5b5259037f97a3225990630a846f05cf4f`.

The ball launch centerline remains fixed at x=352: press/hold/drag/release controls **power only**, never aim direction. This change preserves the unused portion of a frame when the ball passes the upper exit and immediately hands it to world physics.

## Files in the archive

- `lib/game/shooter_lane.dart` — exact crossing with remaining time.
- `lib/game/pinball_game.dart` — remainder-aware world transition.
- `test/shooter_lane_test.dart` and `test/gameplay_mechanics_test.dart` — updated regression assertions.
- `test/shooter_exit_handoff_test.dart` — new all-nine-board handoff test.
- `test/trajectory_invariants_test.dart` — Run20's preserved power/rail physics tests.
- `tool/run21_verify_in_worktree.sh` — guarded isolated build path.
- `docs/RUN21_QA_20261123.md` and `docs/RUN21_CURRENT_MANIFEST_20261123.md` — candid QA/asset/status record.
- `RUN21_source.patch` — tracked-file diff for manual review, **not** an automatic merge.

## Safe installation in an already authorized existing Codespace

If an authorized automation is able to upload/extract this folder inside the **pinball** repository, execute the included `tool/run21_verify_in_worktree.sh` once. No new paid Codespace is needed. The script verifies the GitHub origin and exact Run19 baseline, leaves the active checkout as-is, creates a separate sibling worktree and feature branch, runs `dart format`, `flutter analyze`, `flutter test` and `flutter build web --release`, and pushes **only the isolated candidate branch** if every command succeeds. It refuses to overwrite an existing Run21 branch or worktree and never merges development or main.

No browser/Android acceptance is automated by this script. Before any merge/publish, an agent must open the resulting preview in a browser, test all relevant mechanics and visually compare actual runtime images, then obtain owner Android acceptance.

In the current execution environment GitHub branch creation returned HTTP 403, Git CLI lacked credentials, Flutter/Dart SDKs were unavailable, and no browser sign-in was present. Therefore this archive is a persistent engineering handoff, **not an installed live fix**.
