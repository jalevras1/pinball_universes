#!/usr/bin/env bash
# One action in the EXISTING authorized Pinball Universes Codespace.
# Does not touch the active checkout or merge/publish any playable branch.
set -euo pipefail

candidate_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
repo_root="$(git -C "$candidate_root" rev-parse --show-toplevel)"
origin="$(git -C "$repo_root" remote get-url origin)"
case "$origin" in
  https://github.com/jalevras1/pinball_universes|\
  https://github.com/jalevras1/pinball_universes.git|\
  git@github.com:jalevras1/pinball_universes.git) ;;
  *) echo 'STOP: wrong project/repository.' >&2; exit 2 ;;
esac
for tool in flutter dart python3 curl; do
  command -v "$tool" >/dev/null || {
    echo "STOP: existing $tool is not available." >&2; exit 2;
  }
done

source_branch='feature/pinball-run19-exact-shooter-exit-20261123'
source_sha='7b08cf5b5259037f97a3225990630a846f05cf4f'
candidate_branch='feature/pinball-run23-physics-event-telemetry-20261123'
worktree="$(dirname "$repo_root")/pinball_run23_worktree_20261123"
if [[ -e "$worktree" ]] || git -C "$repo_root" show-ref --verify --quiet "refs/heads/$candidate_branch"; then
  echo 'STOP: existing Run23 worktree or branch will not be overwritten.' >&2
  exit 2
fi

git -C "$repo_root" fetch --no-tags origin "$source_branch"
actual_sha="$(git -C "$repo_root" rev-parse FETCH_HEAD)"
if [[ "$actual_sha" != "$source_sha" ]]; then
  echo 'STOP: remote baseline changed; inspect before integrating.' >&2
  exit 2
fi
git -C "$repo_root" worktree add -b "$candidate_branch" "$worktree" "$source_sha"

# Full cumulative source, including the not-yet-installed Run21/22 mechanics.
for path in \
  lib/main.dart lib/developer_console.dart \
  lib/game/developer_scenarios.dart lib/game/pinball_game.dart \
  lib/game/shooter_lane.dart \
  test/gameplay_mechanics_test.dart test/shooter_lane_test.dart \
  test/shooter_exit_handoff_test.dart test/trajectory_invariants_test.dart \
  test/developer_console_test.dart test/run23_ball_path_and_contact_test.dart; do
  install -Dm644 "$candidate_root/$path" "$worktree/$path"
done

cd "$worktree"
dart format lib/main.dart lib/developer_console.dart \
  lib/game/developer_scenarios.dart lib/game/pinball_game.dart \
  lib/game/shooter_lane.dart test/gameplay_mechanics_test.dart \
  test/shooter_lane_test.dart test/shooter_exit_handoff_test.dart \
  test/trajectory_invariants_test.dart test/developer_console_test.dart \
  test/run23_ball_path_and_contact_test.dart
flutter pub get
flutter analyze
flutter test
flutter build web --release
git diff --check

# A distinct candidate-only preview; do not replace the live Codespace port.
preview_port=8766
if ! python3 -c 'import socket,sys; s=socket.socket(); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); rc=s.connect_ex(("127.0.0.1",int(sys.argv[1]))); s.close(); sys.exit(0 if rc!=0 else 1)' "$preview_port"; then
  echo 'STOP: preview port 8766 is occupied. Build remains in isolated worktree.' >&2
  exit 2
fi
python3 -m http.server "$preview_port" --bind 0.0.0.0 --directory "$worktree/build/web" \
  >"$worktree/run23_preview.log" 2>&1 &
preview_pid=$!
for attempt in 1 2 3 4 5 6 7 8 9 10; do
  if curl --fail --silent --output /dev/null "http://127.0.0.1:$preview_port/"; then break; fi
  sleep 0.3
done
if ! curl --fail --silent --output /dev/null "http://127.0.0.1:$preview_port/"; then
  echo 'STOP: preview did not respond. Inspect run23_preview.log.' >&2
  exit 2
fi
echo "RUN23 PREVIEW READY: open forwarded port $preview_port (pid $preview_pid)."
echo 'Browser/phone QA is still required before any merge.'

git add lib/main.dart lib/developer_console.dart lib/game/developer_scenarios.dart \
  lib/game/pinball_game.dart lib/game/shooter_lane.dart \
  test/gameplay_mechanics_test.dart test/shooter_lane_test.dart \
  test/shooter_exit_handoff_test.dart test/trajectory_invariants_test.dart \
  test/developer_console_test.dart test/run23_ball_path_and_contact_test.dart
git commit -m 'STAGED Run23 event-fed physics diagnostics and solver regression'
git push --set-upstream origin "$candidate_branch"
echo 'STAGED ONLY: separate web preview and Android QA still gate promotion.'
