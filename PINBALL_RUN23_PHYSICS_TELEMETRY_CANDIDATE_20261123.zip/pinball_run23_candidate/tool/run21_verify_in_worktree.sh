#!/usr/bin/env bash
# Run only inside an existing, authorized pinball Codespace checkout.
# This script NEVER switches the active playable checkout or touches main.
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
repo_root="$(git -C "$script_dir" rev-parse --show-toplevel)"
remote_url="$(git -C "$repo_root" remote get-url origin)"
case "$remote_url" in
  https://github.com/jalevras1/pinball_universes|\
  https://github.com/jalevras1/pinball_universes.git|\
  git@github.com:jalevras1/pinball_universes.git) ;;
  *) echo 'STOP: This is not the approved Pinball Universes origin.' >&2; exit 2 ;;
esac

command -v flutter >/dev/null || { echo 'STOP: Flutter SDK unavailable.' >&2; exit 2; }
command -v dart >/dev/null || { echo 'STOP: Dart SDK unavailable.' >&2; exit 2; }

expected_base='7b08cf5b5259037f97a3225990630a846f05cf4f'
base_branch='feature/pinball-run19-exact-shooter-exit-20261123'
feature_branch='feature/pinball-run21-shooter-handoff-tests-20261123'
target="$(dirname "$repo_root")/pinball_run21_worktree_20261123"

if [[ -e "$target" ]] || git -C "$repo_root" show-ref --quiet --verify "refs/heads/$feature_branch"; then
  echo 'STOP: Run21 worktree or branch already exists; no overwrite.' >&2
  exit 2
fi

git -C "$repo_root" fetch --no-tags origin "$base_branch"
actual_base="$(git -C "$repo_root" rev-parse FETCH_HEAD)"
if [[ "$actual_base" != "$expected_base" ]]; then
  echo 'STOP: Run19 source changed; inspect new HEAD before applying.' >&2
  exit 2
fi

git -C "$repo_root" worktree add -b "$feature_branch" "$target" "$expected_base"
for path in \
  lib/game/shooter_lane.dart \
  lib/game/pinball_game.dart \
  test/gameplay_mechanics_test.dart \
  test/shooter_lane_test.dart \
  test/shooter_exit_handoff_test.dart \
  test/trajectory_invariants_test.dart; do
  install -Dm644 "$script_dir/$path" "$target/$path"
done

cd "$target"
dart format lib/game/shooter_lane.dart lib/game/pinball_game.dart \
  test/gameplay_mechanics_test.dart test/shooter_lane_test.dart \
  test/shooter_exit_handoff_test.dart test/trajectory_invariants_test.dart
flutter pub get
flutter analyze
flutter test
flutter build web --release
git diff --check
git add lib/game/shooter_lane.dart lib/game/pinball_game.dart \
  test/gameplay_mechanics_test.dart test/shooter_lane_test.dart \
  test/shooter_exit_handoff_test.dart test/trajectory_invariants_test.dart
git commit -m 'STAGED Run21 frame-complete shooter handoff and mechanics regressions'
git push --set-upstream origin "$feature_branch"

echo 'STAGED RUN21: analyzer, tests, web build passed in isolated worktree.'
echo 'NOT MERGED/DEPLOYED: browser gameplay and owner Android QA still required.'
