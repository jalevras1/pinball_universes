#!/usr/bin/env bash
# Safe one-action Run22 integration for the EXISTING pinball Codespace only.
# The active checkout and both playable branches are never switched or merged.
set -euo pipefail

candidate_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
repo_root="$(git -C "$candidate_root" rev-parse --show-toplevel)"
origin="$(git -C "$repo_root" remote get-url origin)"
case "$origin" in
  https://github.com/jalevras1/pinball_universes|\
  https://github.com/jalevras1/pinball_universes.git|\
  git@github.com:jalevras1/pinball_universes.git) ;;
  *) echo 'STOP: Origin is not the approved Pinball Universes repository.' >&2; exit 2 ;;
esac
command -v flutter >/dev/null || { echo 'STOP: Existing Flutter SDK not found.' >&2; exit 2; }
command -v dart >/dev/null || { echo 'STOP: Existing Dart SDK not found.' >&2; exit 2; }

base_branch='feature/pinball-run19-exact-shooter-exit-20261123'
expected_base='7b08cf5b5259037f97a3225990630a846f05cf4f'
feature_branch='feature/pinball-run22-developer-console-20261123'
worktree="$(dirname "$repo_root")/pinball_run22_worktree_20261123"
if [[ -e "$worktree" ]] || git -C "$repo_root" show-ref --verify --quiet "refs/heads/$feature_branch"; then
  echo 'STOP: The isolated Run22 worktree/branch already exists; no overwrite.' >&2
  exit 2
fi

git -C "$repo_root" fetch --no-tags origin "$base_branch"
actual_base="$(git -C "$repo_root" rev-parse FETCH_HEAD)"
if [[ "$actual_base" != "$expected_base" ]]; then
  echo 'STOP: Baseline SHA changed; inspect the remote source first.' >&2
  exit 2
fi
git -C "$repo_root" worktree add -b "$feature_branch" "$worktree" "$expected_base"

# Includes all Run21 shooter changes because Run21 was not pushed to GitHub.
for path in \
  lib/main.dart \
  lib/developer_console.dart \
  lib/game/developer_scenarios.dart \
  lib/game/pinball_game.dart \
  lib/game/shooter_lane.dart \
  test/gameplay_mechanics_test.dart \
  test/shooter_lane_test.dart \
  test/shooter_exit_handoff_test.dart \
  test/trajectory_invariants_test.dart \
  test/developer_console_test.dart; do
  install -Dm644 "$candidate_root/$path" "$worktree/$path"
done

cd "$worktree"
dart format lib/main.dart lib/developer_console.dart \
  lib/game/developer_scenarios.dart lib/game/pinball_game.dart \
  lib/game/shooter_lane.dart test/gameplay_mechanics_test.dart \
  test/shooter_lane_test.dart test/shooter_exit_handoff_test.dart \
  test/trajectory_invariants_test.dart test/developer_console_test.dart
flutter pub get
flutter analyze
flutter test
flutter build web --release
git diff --check
git add lib/main.dart lib/developer_console.dart lib/game/developer_scenarios.dart \
  lib/game/pinball_game.dart lib/game/shooter_lane.dart \
  test/gameplay_mechanics_test.dart test/shooter_lane_test.dart \
  test/shooter_exit_handoff_test.dart test/trajectory_invariants_test.dart \
  test/developer_console_test.dart
git commit -m 'STAGED Run22 live developer test console and Run21 mechanics'
git push --set-upstream origin "$feature_branch"

echo 'RUN22 STAGED: analyzer/tests/release web build passed in isolated worktree.'
echo 'DO NOT MERGE: distinct browser preview + nine-board and Android QA remain.'
