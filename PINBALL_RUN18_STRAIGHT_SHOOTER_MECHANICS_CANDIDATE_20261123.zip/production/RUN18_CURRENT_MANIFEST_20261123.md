# Pinball Universes — consolidated latest milestone (Run 18)

Source of truth: GitHub `jalevras1/pinball_universes`, branch `chatgpt-pinball-development` at `0dc54ea1e01c9a6deb83d0c110f74fe7542425ac` (verified Nov 23, 2026).
No remote update made. Current playable nine-table prototype must remain intact.

## Machine / asset register

| Universe | Machine | Saved art source | Live premium visual | Full mechanics QA |
| --- | --- | --- | --- | --- |
| Celestial | Astral Orrery | Package A | pending | pending |
| Celestial | Moonfall Sanctuary | Package B | pending | pending |
| Celestial | Nebula Tempest | Package C | pending | pending |
| Neon | Circuit Velocity | Package A | pending | pending |
| Neon | Quantum Grid | Package B | pending | pending |
| Neon | Reactor Rush | Package C | pending | pending |
| Clockwork | Grand Mechanism | Package A | pending | pending |
| Clockwork | Chrono Citadel | Package B | pending | pending |
| Clockwork | Brass Labyrinth | Package C | pending | pending |

Package A: `PINBALL_ARCADE_MACHINE_INTEGRATION_STAGE_20261123.zip` (Library `libfile_71a9aa4c4dbc8191ab8c6f7c0b8863d5`).
Package B: `PINBALL_THREE_MACHINE_VARIANTS_BATCH_20261123.zip` (`libfile_d1b4134c76b0819191cdfd9ad202fc26`).
Package C: `PINBALL_THREE_FINAL_VARIANTS_BATCH_20261123.zip` (`libfile_42fd84dc1f208191aefab3b0061d422f`).
Earlier nine-board manifest: `PINBALL_NINE_MACHINE_ART_MANIFEST_20261123.md` (`libfile_0e97beca10cc8191bbd6688d2a385fce`).

## Engineering evolution and mapping

- Runs 05–10 staged swept rail contact, plunger, calibration, multitouch, geometry audit, flipper-motion candidates; not assumed installed.
- Runs 11–12 staged original mechanical/thematic audio and event controller; not installed.
- Runs 13–16 preserved illustrated hardware, all nine asset candidate packages, and static geometry anchors; none fully passed runtime gates.
- Run 17 staged touch-drag power launcher (`PINBALL_RUN17_PLUNGER_CANDIDATE_20261123.zip`), but retained horizontal launch bias.
- **Run 18** creates source changes against actual GitHub HEAD: fixed vertical tube at x=352, exit y=198, ready y=653, gravity 670, power-to-speed 650–1450, weak recapture, tap/cancel safeguards and swept rail contact. Runtime debugger tests cover all nine current table IDs. This is an **unmerged candidate**, not a shipped machine.

## Next acceptance checkpoints

1. Authorized existing Codespace must run Flutter analyzer, complete widget/physics tests and web release build.
2. Browser gameplay validation of weak/medium/full shot, ball rearm, upper guide trajectory, dual flippers, collision and scoring, drains and replays; inspect runtime mobile screenshots.
3. Correct flipper swept-contact physics and board-specific upper shooter/ramp routing; align three flagship illustrated assets, then six more boards with mechanical maps.
4. Retain rollback/base commit. Promote only after all four gates and owner phone acceptance.
