#!/usr/bin/env bash
set -Eeuo pipefail

# Run only after unzipping PINBALL_ART_AUDIO_UPDATE.zip into
# .pinball_update_staging inside the existing pinball Codespace.
# No Flutter SDK installs, no Dragon files, no deletion of user projects.
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="/workspaces/pinball_universes"

if [[ ! -d "$REPO_DIR/.git" ]] ||
   [[ "$(git -C "$REPO_DIR" branch --show-current)" != 'chatgpt-pinball-development' ]]; then
  echo 'STOP: Open the pinball_universes Codespace on chatgpt-pinball-development.'
  exit 2
fi

if [[ ! -f "$SRC_DIR/assets/backplates/celestial.png" ]] ||
   [[ ! -f "$SRC_DIR/assets/audio/launch.wav" ]] ||
   [[ ! -f "$SRC_DIR/lib/audio/pinball_audio.dart" ]] ||
   [[ ! -f "$SRC_DIR/pubspec.lock" ]]; then
  echo 'STOP: The staged art-and-sound ZIP is incomplete. Nothing was changed.'
  exit 3
fi

cd "$REPO_DIR"
if [[ ! -f assets/universe_covers/celestial.png ]] ||
   [[ ! -f assets/gameplay/bumper_celestial.png ]]; then
  echo 'STOP: The original pinball art is missing. Nothing was changed.'
  exit 4
fi

SDK="$HOME/pinball_flutter_prebuilt_3501/flutter/bin/flutter"
if [[ ! -x "$SDK" ]]; then
  echo 'STOP: The previously working Flutter 3.50.1 SDK was not found.'
  echo 'No installation attempt was made. Nothing was changed.'
  exit 5
fi

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="$REPO_DIR/.pinball_update_backup/$STAMP"
mkdir -p "$BACKUP_DIR"
for path in pubspec.yaml pubspec.lock lib/main.dart lib/game/pinball_game.dart README.md .gitignore; do
  if [[ -f "$path" ]]; then
    mkdir -p "$BACKUP_DIR/$(dirname "$path")"
    cp -p "$path" "$BACKUP_DIR/$path"
  fi
done
if [[ -d build/web ]]; then
  mkdir -p "$BACKUP_DIR/build"
  cp -a build/web "$BACKUP_DIR/build/web"
fi
echo "SAFE_BACKUP=$BACKUP_DIR"

# If package resolution, tests or compilation fails, put the previously
# working Dart code, manifest and preview back automatically. The newly added
# optional images/audio are left intact (removing files is unnecessary).
restore_after_error() {
  local result="$?"
  trap - ERR
  set +e
  echo "PINBALL UPDATE FAILED (exit $result). Restoring last working game..."
  for path in pubspec.yaml pubspec.lock lib/main.dart lib/game/pinball_game.dart README.md .gitignore; do
    if [[ -f "$BACKUP_DIR/$path" ]]; then
      cp -p "$BACKUP_DIR/$path" "$REPO_DIR/$path"
    fi
  done
  if [[ -d "$BACKUP_DIR/build/web" ]]; then
    mkdir -p "$REPO_DIR/build/web"
    cp -a "$BACKUP_DIR/build/web/." "$REPO_DIR/build/web/"
  fi
  echo 'Last known working game restored. No Git commit was made for this failure.'
  echo "Backup remains at $BACKUP_DIR"
  exit "$result"
}
trap restore_after_error ERR

mkdir -p lib/audio assets/backplates assets/audio assets/gameplay tools test
cp -p "$SRC_DIR/lib/main.dart" lib/main.dart
cp -p "$SRC_DIR/lib/game/pinball_game.dart" lib/game/pinball_game.dart
cp -p "$SRC_DIR/lib/audio/pinball_audio.dart" lib/audio/pinball_audio.dart
cp -p "$SRC_DIR/pubspec.yaml" pubspec.yaml
cp -p "$SRC_DIR/pubspec.lock" pubspec.lock
cp -p "$SRC_DIR/.gitignore" .gitignore
cp -p "$SRC_DIR/README.md" README.md
cp -p "$SRC_DIR/test/premium_assets_test.dart" test/premium_assets_test.dart
cp -p "$SRC_DIR/test/widget_test.dart" test/widget_test.dart
cp -p "$SRC_DIR/tools/generate_audio.py" tools/generate_audio.py
cp -a "$SRC_DIR/assets/backplates/." assets/backplates/
cp -a "$SRC_DIR/assets/audio/." assets/audio/
for name in portal_celestial.png reactor_neon.png gear_clockwork.png; do
  cp -p "$SRC_DIR/assets/gameplay/$name" "assets/gameplay/$name"
done
echo 'PINBALL ART AND AUDIO FILES COPIED'

export FLUTTER_SUPPRESS_ANALYTICS=true
export DART_VM_OPTIONS='--old_gen_heap_size=2048'
export NO_PROXY="${NO_PROXY:+$NO_PROXY,}localhost,127.0.0.1,::1"
export no_proxy="$NO_PROXY"
echo 'Running Flutter dependency resolution...'
"$SDK" pub get
echo 'Running Flutter code checks...'
"$SDK" analyze --no-fatal-infos --no-fatal-warnings
"$SDK" test --reporter expanded
echo 'Building web game with verified prebuilt SDK...'
"$SDK" build web --release --no-wasm-dry-run --no-pub

# Only save to GitHub once all build/test gates have passed.
git add .gitignore README.md pubspec.yaml pubspec.lock \
  lib/main.dart lib/game/pinball_game.dart lib/audio/pinball_audio.dart \
  test/premium_assets_test.dart test/widget_test.dart tools/generate_audio.py \
  assets/backplates assets/audio \
  assets/gameplay/portal_celestial.png \
  assets/gameplay/reactor_neon.png \
  assets/gameplay/gear_clockwork.png
# Persist the existing Flutter scaffold too: earlier GitHub commits lacked it.
for path in web android .metadata analysis_options.yaml; do
  if [[ -e "$path" ]]; then git add "$path"; fi
done
if ! git diff --cached --quiet; then
  git commit -m 'Integrate premium pinball backplates, live hazards and original SFX'
  if git push -u origin chatgpt-pinball-development; then
    echo 'PINBALL UPDATE SAVED TO GITHUB'
  else
    echo 'WARNING: Build works; GitHub push failed. Local Git commit is preserved.'
  fi
fi

if ! curl --noproxy '*' -sIf --max-time 3 http://127.0.0.1:8766/ >/dev/null; then
  nohup python3 -m http.server 8766 --bind 0.0.0.0 --directory build/web \
    > .pinball_preview.log 2>&1 < /dev/null &
fi
echo 'PINBALL ART AUDIO UPDATE VERIFIED: WEB BUILD SUCCESSFUL'
echo 'Open or refresh Codespaces port 8766 on your phone.'
